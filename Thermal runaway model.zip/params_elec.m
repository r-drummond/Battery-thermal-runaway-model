function [params,mats] = params_elec(params,mats)
    
% Loads the parameters used for the thermal response of the battery pack model.  
% Ref: Cai, Ting, Anna G. Stefanopoulou, and Jason B. Siegel. "Modeling li-ion battery temperature and expansion force during the early stages of thermal runaway triggered by internal shorts." Journal of The Electrochemical Society 166.12 (2019): A2431.

%% Parameter of the equivalent circuit
params.Qmax = 3.3441e3; % The maximum capacity of the cells. 
R = 0.042; % The series resistance
params.r_set = [0.0213;0.0108]; % The resistances of the equivalent circuit model's RC pairs.
params.tau_set = [4532.8248; 6.835211999999999e+03]; % The time constants of the equivalent circuit model's RC pairs
params.C_set = [params.tau_set(1)/params.r_set(1); params.tau_set(2)/params.r_set(2)]; % The capacitances of the equivalent circuit model's RC pairs.

params.R_short = 4.7e-2; % Store the short circuit resistance. Value taken from reference in the header.
params.R_short_trigger = 4.7e-2; % Store the short circuit resistance. Value taken from reference in the header.

params.Iavg = 5;
%% Parameter of the equivalent circuit model of the whole pack.
params.R_cells = zeros(params.n_cells,1); % Store the series resistances of all the cells in the pack.
params.r =  zeros(params.n_cells,1);  % Store the RC-pair resistances of all the cells in the pack.
params.C = zeros(params.n_cells,1); % Store the RC-pair capacitances of all the cells in the pack.
params.tau =  zeros(params.n_cells,1); % Store the RC-pair time constants of all the cells in the pack.
params.Q =  zeros(params.n_cells,1); % Store the capacitances of all the cells in the pack.

for j = 1:params.n_cells
    params.R_cells(j) = R; % Store the series resistance.
    params.R_cells(j) = R*(1+5e-1*(rand-0.5)); % Store the series resistance.
    params.r(j,1:params.nw) = params.r_set(1);  % Store the RC-pair resistances of all the cells in the pack.
    params.C(j,1:params.nw) = params.C_set(1); % Store the RC-pair capacitances of all the cells in the pack.
    params.tau(j, 1:params.nw) = params.tau_set(1); % Store the RC-pair time constants of all the cells in the pack.
    params.Q(j,1) = params.Qmax; % Store the capacitances of all the cells in the pack.
end

%% This is the series resistance of each parallel branch.
params.R_par = zeros(params.par_num,1); params.R_vec = zeros(params.n_cells,1); % Initalise the resistances of the parallel branches. 
counter = 1;
for j = 1:params.par_num
    R_sum = 0;
    for fg = 1:params.series_num
    params.R_par(j) = R_sum+params.R_cells(counter); % The resistances of each parallel branch. 
    counter = counter+1;
    end
end

params.R = diag(params.R_par); % Store the resistances of each parallel branch. 

end























