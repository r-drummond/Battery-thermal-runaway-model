clc; close all; clear;
%%
% Run this file to initialise the simulink model and plot the models
% response in MATLAB.

%%  Define the number of cells and states of the model.
params = struct; mats = struct; % Structures to store the model parameters and matrices.

params.par_num = 2; % The number of parallel branches in the pack.
params.series_num = 4; % The number of cells in series in each parallel branch.

num_states_temp = 3; % The number of temperatures of each cell in the model, one for the core region, one for the middle and one for the surface.
params.nw = 2;  %The number of RC pairs of the cell equivalent circuit model.
params.n_elec = params.nw+1; % The number of voltages in the equivalent circuit model. One for the series capacitance modelling the SoC and the rest being the voltage drop across the RC pairs.
params.n_cells = params.series_num*params.par_num; % Total number of cells in the pack. This is the #parallel branches X the number of cells in series per branch.
params.n_states = params.n_elec*params.n_cells; % The total number of voltages simulated in the pack model.
params.n_statesT = num_states_temp*params.n_cells; % The number of temperature modelling in the pack. This is #cells X #temperatures modelled per cell- being the core, middle and surface of the cell.
params.n_TR = 18; % The number of states per cell of the thermal runaway simulations.

n_TR = params.n_TR;
n_cells = params.n_cells;


%% Load the model parameters
[params,mats] = params_elec(params,mats); % Load the electrical parameters of the pack model.
[params,mats] = params_thermal(params,mats); % Load the thermal parameters of the pack model.

%% Load the drive cycle current and thermal runaway data from [1] in the header.
cd('./Data/TR data');
load('noise_file.mat'); % Load a file that contains the data for the drive cycle current.
arc1 = load('Pouch300s_discharge.mat'); arc2 = load('ARC2_data2.mat'); % Load the thermal runaway data.
cd('../../');
drive_cycle = I_drive/2e1; % Store the drive cycle current.
cell_ISC = zeros(params.n_cells,1); cell_ISC(1) = 1; % Used to indicate the cell number in the pack where the short circuit is triggered.
C_rate = 1; % Define the C-rate of the constant current simulations.
Icc = params.par_num*C_rate*params.Qmax/3600; % Convert from C-rate to applied current.
tf_cc = 3600/(C_rate+0.3);
%% Build the matrices for the electrical dynamics of the pack model.
mats.A_elec_sim= zeros(params.series_num*2*params.par_num,params.series_num*2*params.par_num);  mats.B_elec_sim= zeros(2*params.series_num*params.par_num,params.par_num); % Initialise the matrices for the electrical dynamics of the pack.

counter = 1; counter_cell = 1;
for i = 1:params.par_num
    tau_par_init = params.Q(i); C_par_init = params.C;
    for j = 1:params.series_num
        mats.A_elec_sim(counter:counter+params.nw,counter:counter+params.nw) = blkdiag(0,-diag(params.tau(counter_cell,:))^(-1)); % The A matrix of the electrical dynamics
        mats.B_elec_sim(counter:counter+params.nw,i) = [params.Q(counter_cell)^(-1);params.C(counter_cell,:)'.^(-1)]; % The B matrix of the electrical dynamics
        counter = counter+params.n_elec;
        counter_cell = counter_cell+1;
    end
end

mats.Wsum = [0,ones(1,params.nw),zeros(1,num_states_temp)]; % A matrix used to sum the voltages stored in the capacitances of the RC pairs.
cd('./Simulations');
[mats.Pi_ocv,mats.Pi_I] = compute_output_voltages(params.par_num,params.R,mats,params); % Matrices that allow the current distribtions in the parallel connected packs to be determined.

%% Build the matrices for the thermal dynamics of the pack model.
mat_lin0 = ([-1/params.r_m2s-1/params.r_s2a,1/params.r_m2s,0; 1/params.r_m2s,-1/params.r_m2s-1/params.r_m2c,1/params.r_m2c;0, 1/params.r_m2c, -1/params.r_m2c]); % Matrix determining the heat transfer between the core, middle and surface regions of the cell.
ambient_term0 = 1*[1/params.r_s2a;0;0]; % Initalise matrix to determine the flux between the atmosphere and the cell surfaces.

mat_lin = mat_lin0; % Initialise the matrix for the heat transfer between the core, middle and surface regions of each cell in the pack.
ambient_term = zeros(3*params.n_cells,1); % Initialise the matrix for the heat transfer between the cell surfaces in the pack and ambient temperature.

mats.Tinv =  params.Cp*params.mass_total*eye(params.n_cells); % The left-hand-side of the thermal dynamics equation.
mats.Tinv_surf =  params.Cp*params.m_surf*eye(params.n_cells); % The left hand side of the thermal dynamics equation at the cell surface.
mats.Tinv_core =  params.Cp*params.m_core*eye(params.n_cells); % The left hand side of the thermal dynamics equation at the cell core.

Tinv_sections0 =  params.Cp*blkdiag(params.m_surf,params.m_mid,params.m_core); mats.Tinv_sections = Tinv_sections0; % Initalise the LHS for the thermal dynamics equation

Z_sim = zeros(params.n_cells, params.n_states); % Initalise matrix to extract the SoC.
W_sim = zeros(params.n_cells, params.n_states); % Initalise matrix to extract the votlages of the capacitors in the RC pairs.
Tsurf = zeros(params.n_cells, params.n_statesT); % Initalise matrix to extract the cell surface temperatures.
Tmid = zeros(params.n_cells, params.n_statesT);  % Initalise matrix to extract the cell middle temperatures.
Tcore = zeros(params.n_cells, params.n_statesT); % Initalise matrix to extract the cell core temperatures.

for i = 1:params.n_cells
    Z_sim(i,params.n_elec*(i-1)+1) =1; % Matrix to extract the SoC.
    W_sim(i,params.n_elec*(i-1)+2:params.n_elec*(i-1)+params.nw+1) =ones(1,params.nw);  % Matrix to extract the votlages of the capacitors in the RC pairs.
    Tsurf(i,3*i-2) = 1; % Matrix to extract the cell surface temperatures.
    Tmid(i,3*i-1) = 1; % Matrix to extract the cell middle temperatures.
    Tcore(i,3*i) = 1; % Matrix to extract the cell core temperatures.
    ambient_term((i-1)*3+1:i*3,1) = ambient_term0; % Matrix to determine the flux between the atmosphere and the cell surfaces.
    if i ~=params.n_cells
        mat_lin = blkdiag(mat_lin, mat_lin0); % Matrix for the heat distribution between the cell core, middle and surface of each cell in the pack.
        mats.Tinv_sections  = blkdiag(mats.Tinv_sections,Tinv_sections0); % Matrix for the LHS of the thermal dynamics of each cell in the pack.
    end
end

%% Matrices for the simulation of the single cell
mat_lin0_single = ([-1/params.r_m2s-4/params.r_s2a,1/params.r_m2s,0; 1/params.r_m2s,-1/params.r_m2s-1/params.r_m2c,1/params.r_m2c;0, 1/params.r_m2c, -1/params.r_m2c]); % Matrix determining the heat transfer between the core, middle and surface regions of the cell.
A_single = blkdiag(0,-eye(params.nw)/diag(params.tau_set));
mass_single = blkdiag(eye(3),params.Cp*blkdiag(params.m_surf,params.m_mid,params.m_core));
mats.A_single = mass_single\blkdiag(A_single,mat_lin0_single);
mats.B_single =mass_single\[[1/params.Q(1,1);1./params.C_set],zeros(params.n_elec,2); zeros(3,1),(ones(3,1)),ambient_term0*4];

%%
mats.Tsurf = Tsurf;
OCV_ser_par = zeros(params.par_num, params.n_cells); % Initialise matrix storing the OCV of the each parallel branch.
ones_series = ones(1,params.series_num);
w_ser_par = zeros(params.par_num, params.n_cells);  % Initialise matrix storing the voltage drop in the RC pairs of each parallel branch.
mats.heat_rates = zeros(params.n_statesT,params.n_cells);  % Initialise matrix heating rates for each cell.
ones_series_temp = ones(num_states_temp*params.series_num,1);

for i = 1:params.par_num
    OCV_ser_par(i,(i-1)*params.series_num+1:i*params.series_num) = ones_series;
    w_ser_par(i,(i-1)*params.series_num+1:i*params.series_num) = ones_series;
    mats.heat_rates((i-1)*(num_states_temp*params.series_num)+1:i*(num_states_temp*params.series_num),i) = ones_series_temp;
end

mats.heat_rates = kron(eye(params.n_cells),[1;1;1]);

%% This section builds the matrix for the heat transfer between two cells in the pack caused by conduction through the air.
connections_tabs = zeros(params.n_cells,params.n_cells); connections_tabs_front_bar = zeros(params.n_cells,params.n_cells); connections_spacing = zeros(params.n_cells,params.n_cells);

counter = 1;
for i = 1:params.par_num
    for j = 1:params.series_num
        for g = 1:params.series_num
            if g == j+1
                connections_spacing((i-1)*params.series_num+j,(i-1)*params.series_num+g) =1;
            end
            if g == j-1
                connections_spacing((i-1)*params.series_num+j,(i-1)*params.series_num+g) =1;
            end
        end
        if i ~= params.par_num
            connections_spacing(counter,(1)*params.series_num+counter) =1;
            connections_spacing((1)*params.series_num+counter,counter) =1;
        end
        counter = counter+1;
    end
end

cells_around_number = zeros(params.n_cells,1);
for j = 1:params.n_cells
    cells_around_number(j) = sum(connections_spacing(j,:));
    connections_spacing(j,j) = -cells_around_number(j);
end

%% Matrix that determines the ratio heat is exchanged with the ambient air.
connections_ambient = zeros(params.n_cells,1);
for j = 1:params.n_cells
    connections_ambient(j) = 4-cells_around_number(j);
end

params.spacing = 1;
spacing_sum_par = 0; spacing_sum_series = 0;
for i = 1:params.par_num
    spacing_sum_par = spacing_sum_par+ 1/(i*params.spacing);
end
for i = 1:params.series_num
    spacing_sum_series = spacing_sum_series+ 1/(i*params.spacing);
end

%% Matrix defining how cells are connected through the tabs. Used for the heat transfer through the tabs.
counter = 1;
for i = 1:params.par_num
    for j = 1:params.series_num
        for g = 1:params.series_num
            if j ~= g
                connections_tabs((i-1)*params.series_num+g,(i-1)*params.series_num+g) = connections_tabs((i-1)*params.series_num+g,(i-1)*params.series_num+g) -1/((abs(g-j))*params.spacing);
                connections_tabs((i-1)*params.series_num+j,(i-1)*params.series_num+g) = 1/((abs(g-j))*params.spacing);
            end
        end
        counter = counter+1;
    end
    % This is the heat conduction associated with the front tab bar on the pack, that distributes the current across the parallel branches.
    for g = 1:params.par_num
        if g~= i
            connections_tabs_front_bar((i-1)*params.series_num+1,(g-1)*params.series_num+1) = 1/((abs(g-i))*params.spacing);
        end
        
    end
    connections_tabs_front_bar((i-1)*params.series_num+1,(i-1)*params.series_num+1) = -sum(connections_tabs_front_bar((i-1)*params.series_num+1,:));
end

%% Turns the above matrices defining heat conduction and radiation into those used in the model.
mats.A_rad = params.rad_param*connections_spacing; % Matrix for the heat transfer between cells in the pack due to radiation.
mats.A_con_spacing = params.con_air_param*connections_spacing;
mats.A_con_tabs = params.con_tab_param*(connections_tabs+connections_tabs_front_bar); % Matrix for the heat transfer between cells in the pack due to conduction.
mats.A_con_ambient = (1/params.r_s2a)*connections_ambient;
mats.A_con_ambient_rad = params.rad_param*connections_ambient;

mats.A_con = mats.A_con_tabs + mats.A_con_spacing;

mats.ambient_term_quad = kron(mats.A_con_ambient_rad,[1;0;0]); mats.ambient_term_quad_nonkron = kron(mats.A_con_ambient_rad,[1;0;0]);
mats.ambient_term = kron(mats.A_con_ambient,[1;0;0]);

mats.A_con_ambient_rad_TR = diag(mats.A_con_ambient_rad);
mats.A_con_ambient_TR = diag(mats.A_con_ambient);

%% Matrices to extract the thermal runaway states;
mats.xs_core_TR = zeros(params.n_cells,params.n_cells*params.n_TR); mats.xs_m_TR= zeros(params.n_cells,params.n_cells*params.n_TR) ;mats.xs_surface_TR= zeros(params.n_cells,params.n_cells*params.n_TR);
mats.xa_core_TR= zeros(params.n_cells,params.n_cells*params.n_TR); mats.xa_m_TR= zeros(params.n_cells,params.n_cells*params.n_TR); mats.xa_surface_TR= zeros(params.n_cells,params.n_cells*params.n_TR);
mats.SOC_TR= zeros(params.n_cells,params.n_cells*params.n_TR);
mats.z_core_TR= zeros(params.n_cells,params.n_cells*params.n_TR); mats.z_m_TR= zeros(params.n_cells,params.n_cells*params.n_TR); mats.z_surface_TR= zeros(params.n_cells,params.n_cells*params.n_TR);
mats.alpha_core_TR=zeros(params.n_cells,params.n_cells*params.n_TR); mats.alpha_m_TR=zeros(params.n_cells,params.n_cells*params.n_TR);mats.alpha_surface_TR= zeros(params.n_cells,params.n_cells*params.n_TR);
mats.Tc_TR= zeros(params.n_cells,params.n_cells*params.n_TR); mats.Tm_TR= zeros(params.n_cells,params.n_cells*params.n_TR); mats.Ts_TR= zeros(params.n_cells,params.n_cells*params.n_TR);
mats.Tfix_TR= zeros(params.n_cells,params.n_cells*params.n_TR);

for j = 1:params.n_cells
    mats.xs_core_TR(j,(j-1)*params.n_TR+1) = 1; mats.xs_m_TR(j,(j-1)*params.n_TR+2) = 1;mats.xs_surface_TR(j,(j-1)*params.n_TR+3) = 1;
    mats.xa_core_TR(j,(j-1)*params.n_TR+4) = 1; mats.xa_m_TR(j,(j-1)*params.n_TR+5) = 1; mats.xa_surface_TR(j,(j-1)*params.n_TR+6) = 1;
    mats.SOC_TR(j,(j-1)*params.n_TR+7) = 1;
    mats.z_core_TR(j,(j-1)*params.n_TR+8) = 1; mats.z_m_TR(j,(j-1)*params.n_TR+9) = 1; mats.z_surface_TR(j,(j-1)*params.n_TR+10) = 1;
    mats.alpha_core_TR(j,(j-1)*params.n_TR+11) = 1; mats.alpha_m_TR(j,(j-1)*params.n_TR+12) = 1;mats.alpha_surface_TR(j,(j-1)*params.n_TR+13) = 1;
    mats.Tc_TR(j,(j-1)*params.n_TR+14) = 1; mats.Tm_TR(j,(j-1)*params.n_TR+15) = 1; mats.Ts_TR(j,(j-1)*params.n_TR+16) = 1;
    mats.Tfix_TR(j,(j-1)*params.n_TR+17) = 1;
end

%% Build the matrices for the thermal dynamics of the pack model.
mat_lin0 = ([-1/params.r_m2s-connections_ambient(1)/params.r_s2a,1/params.r_m2s,0; 1/params.r_m2s,-1/params.r_m2s-1/params.r_m2c,1/params.r_m2c;0, 1/params.r_m2c, -1/params.r_m2c]); % Matrix determining the heat transfer between the core, middle and surface regions of the cell.
mat_lin = mat_lin0; % Initialise the matrix for the heat transfer between the core, middle and surface regions of each cell in the pack.

for i = 1:params.n_cells
    if i ~=params.n_cells
        mat_lin = blkdiag(mat_lin ,[-1/params.r_m2s-connections_ambient(i+1)/params.r_s2a,1/params.r_m2s,0; 1/params.r_m2s,-1/params.r_m2s-1/params.r_m2c,1/params.r_m2c;0, 1/params.r_m2c, -1/params.r_m2c]); % Matrix for the heat distribution between the cell core, middle and surface of each cell in the pack.
    end
end

%% %% Build the matrices for the thermal dynamics of the pack model.
mats.A_temp = mats.Tinv_sections\mat_lin; % The A matrix of the temperature dynamics.
mats.B_temp= mats.Tinv_sections\[mats.heat_rates, mats.ambient_term,Tsurf'*mats.A_con]; % The B matrix of the temperature dynamics. % have to add the radiation ambient effetcs too
mats.C_temp = [Tsurf;Tmid;Tcore]; % Matrix that ouputs the surface, middle and core temperatures of each cell in the pack.

%% Build the matrices for the heat transfer of the white vapour
 mats.A_vap= -8*eye(params.n_cells,params.n_cells);
 counter = 1;
 for i = 1:params.par_num
     for j = 1:params.series_num
         if j<params.series_num
             mats.A_vap(counter,counter+1) = 1;
             if i<params.par_num
                 mats.A_vap(counter,counter+params.series_num+1) = 1;
             end
             if i>1
                 mats.A_vap(counter,counter-params.series_num+1) = 1;
             end
         end
         if j>1
             mats.A_vap(counter,counter-1) = 1;
             if i<params.par_num
                 mats.A_vap(counter,counter+params.series_num-1) = 1;
                 
             end
             if i>1
                 mats.A_vap(counter,counter-params.series_num-1) = 1;
             end
         end
         if i<params.par_num
             mats.A_vap(counter,counter+params.series_num) = 1;
             
         end
         if i>1
             mats.A_vap(counter,counter-params.series_num) = 1;
         end
         
         counter = counter+1;
     end
 end
 mats.m_vap_set =  kron(eye(params.n_cells),[zeros(params.n_TR-1,1);1]);


%% Establish the initial conditions of the eletrical model.
soc_dchg = 1; %Establish the inital SoC of the cells in the pack.
soc_chg = 0.1;
w0 = zeros(params.nw,1); %Establish the inital relaxtion voltage.
x0_elec_chg0 = [soc_chg;w0]; x0_elec_dchg0 = [soc_dchg;w0]; x0_temp_0 = [params.Tamb;params.Tamb;params.Tamb]; x0_elec_chg = zeros(params.n_states ,1); x0_elec_dchg = zeros(params.n_states ,1);  x0_temp = zeros(params.n_statesT ,1);
for i = 1:params.n_cells % stack the initial condtions up for each cell in the pack.
    x0_elec_chg(params.n_elec*(i-1)+1:params.n_elec*(i)) = x0_elec_chg0;
    x0_elec_dchg(params.n_elec*(i-1)+1:params.n_elec*(i)) = x0_elec_dchg0;
    x0_temp(3*(i)-2:3*(i)) =  x0_temp_0;
end

%% Run the thermal and electrical simulations of a single cell to parameterise against the datasheet
[t,soc,w,Ts,Tm,Tc,v] = run_simulation_single_cell(params,mats);

%% Pack level simulations
x0_pack = [x0_elec_chg;x0_temp];
% [soc_pack, Tc_pack,Tm_pack,Ts_pack] = run_simulation_pack(mats,params,x0_pack);

%% %% Establish the initial conditions of the thermal runaway model.
params.SOC_0 = 1; % Initial SoC
params.xs_0 = 0.15;  % Initial fraction of Li in SEI layer. 
params.alpha_0 = 0.04; % Initialdegree of conversion of cathode decomposition.

[x0_TR0] = initial_conditions(params); % load the thermal runaway initial conditions of one cell.
x0_TR = zeros(params.n_cells*params.n_TR,1); % initialise the initial conditions of the thermal runaway model.

for j = 1:params.n_cells
    x0_TR(params.n_TR*(j)-(params.n_TR-1):params.n_TR*(j),1) = x0_TR0; % Initial conditions of the thermal runaway pack model.
end

%% Run the thermal runaway simulations.
% [x_dot] = run_TR_sim(params,mats,x0_TR0,arc1,arc2);
%  heater = cell_ISC*1;
%%
cd('../')

%
vap0 = zeros(params.n_cells,1);
t= 0;states0 = [x0_TR];

% t = 1;
heater = 0*ones(params.n_cells,1);
x_dot  = TR_test_new(states0,heater,t,mats,params);




