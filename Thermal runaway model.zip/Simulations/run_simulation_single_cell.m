function [t,soc,w,Ts,Tm,Tc,v] = run_simulation_single_cell(params,mats)

%% Simulation of a single cell. Do it for 2A, 4A, 6A, 8A, 10A charging. 
tf = 1e2; n_steps = 3*tf; tspan = linspace(0,tf,n_steps); % set up the simulation time.
params.nw = 2;
x0_single = [1;0;0;ones(3,1)*params.Tamb] ;
% Iapp = 1; [t_single,states_single] = ode15s(@(t_single,states_single)single_test(states_single,Iapp,params,mats,params.Tamb),tspan,x0_single); % Simulate the thermal runaway dynamics

n_t_obs = 3e3; end_frac = 0.99; 
params.factor = 1;
Iapp = 2;  tf = params.factor*end_frac*params.Qmax/abs(Iapp); tspan = linspace(0,tf,n_t_obs );
[t_2,states_2,soc_2,w_2,Ts_2,Tm_2,Tc_2,v_2] = run_and_extract(Iapp,tspan,x0_single,mats,params);
Iapp  = 4;  tf = params.factor*end_frac*params.Qmax/abs(Iapp); tspan = linspace(0,tf,n_t_obs );
[t_4,states_4,soc_4,w_4,Ts_4,Tm_4,Tc_4,v_4] = run_and_extract(Iapp,tspan,x0_single,mats,params);
Iapp  = 6;  tf = params.factor*end_frac*params.Qmax/abs(Iapp); tspan = linspace(0,tf,n_t_obs );
[t_6,states_6,soc_6,w_6,Ts_6,Tm_6,Tc_6,v_6] = run_and_extract(Iapp,tspan,x0_single,mats,params);
Iapp  = 8;  tf = params.factor*end_frac*params.Qmax/abs(Iapp); tspan = linspace(0,tf,n_t_obs );
[t_8,states_8,soc_8,w_8,Ts_8,Tm_8,Tc_8,v_8] = run_and_extract(Iapp,tspan,x0_single,mats,params);
Iapp  = 10;  tf = params.factor*end_frac*params.Qmax/abs(Iapp); tspan = linspace(0,tf,n_t_obs );
[t_10,states_10,soc_10,w_10,Ts_10,Tm_10,Tc_10,v_10] = run_and_extract(Iapp,tspan,x0_single,mats,params);

%% Load the data
cd('../Data/Datasheet/Temp');
data_T_2A = xlsread('2A.xlsx'); data_T_4A = xlsread('4A.xlsx'); data_T_6A = xlsread('6A_mod.xlsx'); data_T_8A = xlsread('8A.xlsx'); data_T_10A = xlsread('10A.xlsx');
cd('../Voltages');
data_V_2A = xlsread('2A.xlsx'); data_V_4A = xlsread('4A.xlsx'); data_V_6A = xlsread('6A.xlsx'); data_V_8A = xlsread('8A.xlsx'); data_V_10A = xlsread('10A.xlsx');
cd('../../../Simulations');

%% This runs a step response, used to help parameterise the mode.
[T_step] = compute_step_response(params);

%% Time derivative of the data. Used to help parameterise the data.
[data_temp_deriv_2A,data_temp_deriv_4A,data_temp_deriv_6A,data_temp_deriv_8A,data_temp_deriv_10A] = derivatives_data(data_T_2A,data_T_4A,data_T_6A,data_T_8A,data_T_10A);

x_dot_2 = zeros(6,n_t_obs);
for j= 1:n_t_obs
    [x_dot_2(:,j)] = single_test(states_2(j,:)',2,params,mats,params.Tamb);
    [x_dot_4(:,j)] = single_test(states_4(j,:)',4,params,mats,params.Tamb);
    [x_dot_6(:,j)] = single_test(states_6(j,:)',6,params,mats,params.Tamb);
    [x_dot_8(:,j)] = single_test(states_8(j,:)',8,params,mats,params.Tamb);
    [x_dot_10(:,j)] = single_test(states_10(j,:)',10,params,mats,params.Tamb);
end

x_dot_2_Ts_interp = interp1(params.Qmax*states_2(:,1)',x_dot_2(4,:),data_T_2A(1:78,1));
x_dot_4_Ts_interp = interp1(params.Qmax*states_4(:,1)',x_dot_4(4,:),data_T_4A(1:81,1));
x_dot_6_Ts_interp = interp1(params.Qmax*states_6(:,1)',x_dot_6(4,:),data_T_6A(1:81,1));
x_dot_8_Ts_interp = interp1(params.Qmax*states_8(:,1)',x_dot_8(4,:),data_T_8A(1:74,1));
x_dot_10_Ts_interp = interp1(params.Qmax*states_10(:,1)',x_dot_10(4,:),data_T_10A(1:79,1));

x_diff_2_interp= (x_dot_2_Ts_interp-data_temp_deriv_2A')./(2*data_T_2A(1:78,2));
x_diff_4_interp= (x_dot_4_Ts_interp-data_temp_deriv_4A')./(4*data_T_4A(1:81,2));
x_diff_6_interp= (x_dot_6_Ts_interp-data_temp_deriv_6A')./(6*data_T_6A(1:81,2));
x_diff_8_interp= (x_dot_8_Ts_interp-data_temp_deriv_8A')./(8*data_T_8A(1:74,2));
x_diff_10_interp= (x_dot_10_Ts_interp-data_temp_deriv_10A')./(10*data_T_10A(1:79,2));

%%
t = [t_2,t_4,t_6,t_8,t_10];
soc = [soc_2,soc_4,soc_6,soc_8,soc_10];
w = [w_2,w_4,w_6,w_8,w_10];
v = [v_2,v_4,v_6,v_8,v_10];
Ts = [Ts_2,Ts_4,Ts_6,Ts_8,Ts_10];
Tm = [Tm_2,Tm_4,Ts_6,Ts_8,Ts_10];
Tc = [Tc_2,Tc_4,Ts_6,Ts_8,Ts_10];

%% Fix some of the data points
data_V_2A = data_V_2A(1:93,:);
data_V_4A = data_V_4A(2:90,:);
data_V_8A = [data_V_8A(1,:);data_V_8A(3:94,:)];
data_V_10A = [data_V_10A(1:9,:);data_V_10A(11:94,:)];
data_T_2A = [data_T_2A(1:62,:);data_T_2A(64:84,:)];

%% % Plot the results. 
colour_AC = 0.9*[1,1,1]; marker_size = 12; line_width = 2; f_size = 12;

fig_Tsurf = figure;
plot((1-soc_2)*(params.Qmax/(1)),Ts_2(:,1)-273,'color',colour_AC,'LineWidth',2,'linestyle','-'); hold on;
plot((1-soc_4)*(params.Qmax/(1)),Ts_4(:,1)-273,'color',colour_AC*4/5,'LineWidth',2,'linestyle','-'); hold on;
plot((1-soc_6)*(params.Qmax/(1)),Ts_6(:,1)-273,'color',colour_AC*3/5,'LineWidth',2,'linestyle','-'); hold on;
plot((1-soc_8)*(params.Qmax/(1)),Ts_8(:,1)-273,'color',colour_AC*2/5,'LineWidth',2,'linestyle','-'); hold on;
plot((1-soc_10)*(params.Qmax/(1)),Ts_10(:,1)-273,'color',colour_AC*1/5,'LineWidth',2,'linestyle','-'); hold on;
xlabel('Discharge capacity (mAh)','interpreter','latex','fontsize',f_size,'interpreter','latex')
ylabel('Surface temperature ($^o$C)','interpreter','latex','fontsize',f_size,'interpreter','latex')
grid on
leg = legend('2A-fit','4A-fit','6A-fit','8A-fit','10A-fit');
set(leg,'interpreter','latex','fontsize',10,'location','northwest')
set(gca,'FontSize',14);
% axis([0 5000 20 65 ])


fig_Tmid = figure;
plot((1-soc_2)*(params.Qmax/(1)),Tm_2(:,1)-273,'color',colour_AC,'LineWidth',2,'linestyle','-'); hold on;
plot((1-soc_4)*(params.Qmax/(1)),Tm_4(:,1)-273,'color',colour_AC*4/5,'LineWidth',2,'linestyle','-'); hold on;
plot((1-soc_6)*(params.Qmax/(1)),Tm_6(:,1)-273,'color',colour_AC*3/5,'LineWidth',2,'linestyle','-'); hold on;
plot((1-soc_8)*(params.Qmax/(1)),Tm_8(:,1)-273,'color',colour_AC*2/5,'LineWidth',2,'linestyle','-'); hold on;
plot((1-soc_10)*(params.Qmax/(1)),Tm_10(:,1)-273,'color',colour_AC*1/5,'LineWidth',2,'linestyle','-'); hold on;
xlabel('Discharge capacity (mAh)','interpreter','latex','fontsize',f_size,'interpreter','latex')
ylabel('Middle temperature ($^o$C)','interpreter','latex','fontsize',f_size,'interpreter','latex')
grid on
leg = legend('2A-fit','4A-fit','6A-fit','8A-fit','10A-fit');
set(leg,'interpreter','latex','fontsize',10,'location','northwest')
set(gca,'FontSize',14);
% axis([0 5000 20 65 ])

fig_Tcore = figure;
plot((1-soc_2)*(params.Qmax/(1)),Tc_2(:,1)-273,'color',colour_AC,'LineWidth',2,'linestyle','-'); hold on;
plot((1-soc_4)*(params.Qmax/(1)),Tc_4(:,1)-273,'color',colour_AC*4/5,'LineWidth',2,'linestyle','-'); hold on;
plot((1-soc_6)*(params.Qmax/(1)),Tc_6(:,1)-273,'color',colour_AC*3/5,'LineWidth',2,'linestyle','-'); hold on;
plot((1-soc_8)*(params.Qmax/(1)),Tc_8(:,1)-273,'color',colour_AC*2/5,'LineWidth',2,'linestyle','-'); hold on;
plot((1-soc_10)*(params.Qmax/(1)),Tc_10(:,1)-273,'color',colour_AC*1/5,'LineWidth',2,'linestyle','-'); hold on;
xlabel('Discharge capacity (mAh)','interpreter','latex','fontsize',f_size,'interpreter','latex')
ylabel('Core temperature ($^o$C)','interpreter','latex','fontsize',f_size,'interpreter','latex')
grid on
leg = legend('2A-fit','4A-fit','6A-fit','8A-fit','10A-fit');
set(leg,'interpreter','latex','fontsize',10,'location','northwest')
set(gca,'FontSize',14);
% axis([0 5000 20 65 ])


fig_v = figure;
plot((1-soc_2)*(params.Qmax/(1e0)),v_2(:,1),'color',colour_AC,'LineWidth',2,'linestyle','-'); hold on;
plot(data_V_2A(:,1),data_V_2A(:,2),'color', colour_AC,'marker','+','linestyle','none','markersize',marker_size,'linewidth',line_width); hold on;
plot((1-soc_4)*(params.Qmax/(1e0)),v_4(:,1),'color',colour_AC*4/5,'LineWidth',2,'linestyle','-'); hold on;
plot(data_V_4A(:,1),data_V_4A(:,2),'color', colour_AC*4/5,'marker','+','linestyle','none','markersize',marker_size,'linewidth',line_width); hold on;
plot((1-soc_6)*(params.Qmax/(1e0)),v_6(:,1),'color',colour_AC*3/5,'LineWidth',2,'linestyle','-'); hold on;
plot(data_V_6A(:,1),data_V_6A(:,2),'color',colour_AC*3/5,'marker','+','linestyle','none','markersize',marker_size,'linewidth',line_width); hold on;
plot((1-soc_8)*(params.Qmax/(1e0)),v_8(:,1),'color',colour_AC*2/5,'LineWidth',2,'linestyle','-'); hold on;
plot(data_V_8A(:,1),data_V_8A(:,2),'color',colour_AC*2/5,'marker','+','linestyle','none','markersize',marker_size,'linewidth',line_width); hold on;
plot((1-soc_10)*(params.Qmax/(1e0)),v_10(:,1),'color',colour_AC*1/5,'LineWidth',2,'linestyle','-'); hold on;
plot(data_V_10A(:,1),data_V_10A(:,2),'color',colour_AC*1/5,'marker','+','linestyle','none','markersize',marker_size,'linewidth',line_width); hold on;
xlabel('Discharge capacity (mAh)','interpreter','latex','fontsize',f_size,'interpreter','latex')
ylabel('Voltage (V)','interpreter','latex','fontsize',f_size,'interpreter','latex')
grid on
leg = legend('2A-fit','2A-data','4A-fit','4A-data','6A-fit','6A-data','8A-fit','8A-data','10A-fit','10A-data');
set(leg,'interpreter','latex','fontsize',10,'location','southwest')
set(gca,'FontSize',14);
% axis([0 5000 20 65 ])


fig_T_fit = figure;
plot((1-soc_2)*(params.Qmax/(1e0)),Ts_2(:,1)-273,'color',colour_AC,'LineWidth',2,'linestyle','-'); hold on;
plot(data_T_2A(:,1),data_T_2A(:,2),'color', colour_AC,'marker','+','linestyle','none','markersize',marker_size,'linewidth',line_width); hold on;
plot((1-soc_4)*(params.Qmax/(1e0)),Ts_4(:,1)-273,'color',colour_AC*4/5,'LineWidth',2,'linestyle','-'); hold on;
plot(data_T_4A(:,1),data_T_4A(:,2),'color', colour_AC*4/5,'marker','+','linestyle','none','markersize',marker_size,'linewidth',line_width); hold on;
plot((1-soc_6)*(params.Qmax/(1e0)),Ts_6(:,1)-273,'color',colour_AC*3/5,'LineWidth',2,'linestyle','-'); hold on;
plot(data_T_6A(:,1),data_T_6A(:,2),'color',colour_AC*3/5,'marker','+','linestyle','none','markersize',marker_size,'linewidth',line_width); hold on;
plot((1-soc_8)*(params.Qmax/(1e0)),Ts_8(:,1)-273,'color',colour_AC*2/5,'LineWidth',2,'linestyle','-'); hold on;
plot(data_T_8A(:,1),data_T_8A(:,2),'color',colour_AC*2/5,'marker','+','linestyle','none','markersize',marker_size,'linewidth',line_width); hold on;
plot((1-soc_10)*(params.Qmax/(1e0)),Ts_10(:,1)-273,'color',colour_AC*1/5,'LineWidth',2,'linestyle','-'); hold on;
plot(data_T_10A(:,1),data_T_10A(:,2),'color',colour_AC*1/5,'marker','+','linestyle','none','markersize',marker_size,'linewidth',line_width); hold on;
xlabel('Discharge capacity (mAh)','interpreter','latex','fontsize',f_size,'interpreter','latex')
ylabel('Temperature ($^o$C)','interpreter','latex','fontsize',f_size,'interpreter','latex')
grid on
leg = legend('2A-fit','2A-data','4A-fit','4A-data','6A-fit','6A-data','8A-fit','8A-data','10A-fit','10A-data');
set(leg,'interpreter','latex','fontsize',10,'location','east')
set(gca,'FontSize',14);
axis([0 5000 20 65 ])



fig_Tdot = figure;
plot((1-soc_2)*(params.Qmax/(1e0)),x_dot_2(4,:)/2,'color',colour_AC,'LineWidth',2,'linestyle','-'); hold on;
plot(data_T_2A(1:78,1),data_temp_deriv_2A,'color', colour_AC,'marker','+','linestyle','none','markersize',marker_size,'linewidth',line_width); hold on;
plot((1-soc_2)*(params.Qmax/(1e0)),x_dot_4(4,:)/4,'color',colour_AC*4/5,'LineWidth',2,'linestyle','-'); hold on;
plot(data_T_4A(1:81,1),data_temp_deriv_4A,'color', colour_AC*4/5,'marker','+','linestyle','none','markersize',marker_size,'linewidth',line_width); hold on;
plot((1-soc_2)*(params.Qmax/(1e0)),x_dot_6(4,:)/6,'color',colour_AC*3/5,'LineWidth',2,'linestyle','-'); hold on;
plot(data_T_6A(1:81,1),data_temp_deriv_6A,'color',colour_AC*3/5,'marker','+','linestyle','none','markersize',marker_size,'linewidth',line_width); hold on;
plot((1-soc_2)*(params.Qmax/(1e0)),x_dot_8(4,:)/8,'color',colour_AC*2/5,'LineWidth',2,'linestyle','-'); hold on;
plot( data_T_8A(1:74,1),data_temp_deriv_8A,'color',colour_AC*2/5,'marker','+','linestyle','none','markersize',marker_size,'linewidth',line_width); hold on;
plot((1-soc_2)*(params.Qmax/(1e0)),x_dot_10(4,:)/10,'color',colour_AC*1/5,'LineWidth',2,'linestyle','-'); hold on;
plot( data_T_10A(1:79,1),data_temp_deriv_10A,'color',colour_AC*1/5,'marker','+','linestyle','none','markersize',marker_size,'linewidth',line_width); hold on;
xlabel('Discharge capacity (mAh)','interpreter','latex','fontsize',f_size,'interpreter','latex')
ylabel('$\dot{Ts}$','interpreter','latex','fontsize',f_size,'interpreter','latex')
grid on
leg = legend('2A-fit','2A-data','4A-fit','4A-data','6A-fit','6A-data','8A-fit','8A-data','10A-fit','10A-data');
set(leg,'interpreter','latex','fontsize',10,'location','east')
set(gca,'FontSize',14);
axis([0 5000 -1e-2 3e-2 ])

print(fig_v   ,'v_fit','-depsc')
print(fig_T_fit  ,'tempfit','-depsc')

end