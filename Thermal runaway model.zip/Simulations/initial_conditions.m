function [x] = initial_conditions(params)

% Loads the initial conditions of the thermal runaway simulation.

SOC = params.SOC_0; % Initial SoC
xs0 = params.xs_0;  % Initial fraction of Li in SEI layer. 
xa0= params.x_an0; % Initial fraction of SEI in anode.
z0 = params.z0; % Initial dimensionless SEI layer thickness.
alpha0 = params.alpha_0 ; % Initialdegree of conversion of cathode decomposition.

alpha_core = alpha0;
alpha_m = alpha0;
alpha_surface = alpha0;
xs_core = xs0;
xs_surface = xs0;
xs_m = xs0;
xa_core = xa0;
xa_m = xa0;
xa_surface = xa0;
z_core = z0;
z_m = z0;
z_surface = z0;

Tc= params.Tamb;
Tm = params.Tamb;
Ts = params.Tamb;
Tfix = params.Tamb;
m_vap = 0;

x = [xs_core;xs_m;xs_surface ;xa_core;xa_m;xa_surface;SOC;z_core;z_m;z_surface;alpha_core;alpha_m;alpha_surface;Tc;Tm;Ts;Tfix;m_vap];

end