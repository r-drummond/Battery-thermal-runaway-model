function [x_dot] = single_test(states,I,params,mats,Tamb)

% this functions computes the derivative of the thermal and electrical model for a
% single cell.

z_vec = [0,0.06407,0.1822,0.2883,0.6233,0.8,0.9419,0.994,1];
p = [2.62; 3.1373;  3.4394;  3.5388; 3.814;3.966;4.0752; 4.1322;4.2531];
c1 = p(1); c2 = p(2); c3 = p(3); c4 = p(4); c5 = p(5);  c6 = p(6); c7 = p(7); c8 = p(8);
b1 = 1/1.3; b2 = 1/1.65; b3 = 1; b4 = 1.2; b5 = 1.2; b6 = 0.8; b7 = 3; b8 = 1;
a1 = (p(2)-p(1))/(z_vec(2))^b1; a2 = (p(3)-p(2))/(z_vec(3)-z_vec(2))^b2; a3 = (p(4)-p(3))/(z_vec(4)-z_vec(3))^b3; a4 = (p(5)-p(4))/(z_vec(5)-z_vec(4))^b4; a5 = (p(6)-p(5))/(z_vec(6)-z_vec(5))^b5; a6 = (p(7)-p(6))/(z_vec(7)-z_vec(6))^b6;a7 = (p(8)-p(7))/(z_vec(8)-z_vec(7))^b7; a8 = (p(9)-p(8))/(z_vec(9)-z_vec(8))^b8;


%%
soc = states(1);
w = states(2:2+params.nw-1);
w_sum = sum(w);
Ts = states(2+params.nw);
Tm = states(2+params.nw+1);
Tc = states(2+params.nw+2);
Tavg = params.core_ratio*Tc+ params.mid_ratio*params.core_ratio*Tm + (1-params.core_ratio-params.core_ratio)*Ts;

%% Account for the drop in resistance caused by an increase in temperature.
R_factor = (exp(params.Tref_R/Tavg)/(exp(params.Tref_R/params.Tamb))); 
% mats.A_elec_sim_mod =  mats.A_single*blkdiag(1,eye(params.nw)/R_factor,eye(3) ); % Arhenius rule for the RC-pair resistance.
% R_mod = params.R_cells(1)*R_factor; % Arhenius rule for the series resistance.

R_mod = params.R_cells(1); % Isothermal.
mats.A_elec_sim_mod =  mats.A_single*blkdiag(1,eye(params.nw)/R_factor,eye(3) ); % Isothermal.
%%
if soc<=z_vec(2)
    OCV_init = a1*(soc)^b1+c1;
elseif soc>=z_vec(2) && soc<=z_vec(3)
    OCV_init = a2*(soc-z_vec(2))^b2+c2;
elseif soc>=z_vec(3) && soc<=z_vec(4)
    OCV_init = a3*(soc-z_vec(3))^b3+c3;
elseif soc>=z_vec(4) && soc<=z_vec(5)
    OCV_init = a4*(soc-z_vec(4))^b4+c4;
elseif soc>=z_vec(5) && soc<=z_vec(6)
    OCV_init = a5*(soc-z_vec(5))^b5+c5;
elseif soc>=z_vec(6) && soc<=z_vec(7)
    OCV_init = a6*(soc-z_vec(6))^b6+c6;
elseif soc>=z_vec(7) && soc<=z_vec(8)
    OCV_init = a7*(soc-z_vec(7))^b7+c7;
elseif soc>=z_vec(8) && soc<=z_vec(9)
    OCV_init = a8*(soc-z_vec(8))^b8+c8;
else
    OCV_init = 0;
end

OCV = OCV_init;

soc_switch = 0.8; soc_switch_2 = 0.4;
cond1 =  1.5*(3e-4*soc_switch-0.8e-4); a1 = -0.3*3.9e-4;
cond2 =  cond1+a1*(soc_switch-soc_switch_2)^1; a2 = 5*3.9e-4;

if soc >= soc_switch
    dUdT = 1.5*max([0,abs(3e-4*soc-0.8e-4)]);
elseif soc >= soc_switch_2 && soc <= soc_switch
    dUdT = cond1+a1*(soc_switch-soc)^1;
elseif soc <= soc_switch_2
    dUdT = cond2+a2*(soc_switch_2-soc);
end

v_diff = (w_sum- R_mod*I);
power = (-I*v_diff +I*Ts*dUdT );

%%
x_dot = mats.A_single*states +  mats.B_single*[-I;power;Tamb];


end

























