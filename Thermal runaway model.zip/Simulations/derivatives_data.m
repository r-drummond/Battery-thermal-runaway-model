function [data_temp_deriv_2A,data_temp_deriv_4A,data_temp_deriv_6A,data_temp_deriv_8A,data_temp_deriv_10A] = derivatives_data(data_T_2A,data_T_4A,data_T_6A,data_T_8A,data_T_10A)

for j = 1:79-1
    data_temp_deriv_2A(j) = (data_T_2A(j+1,2)-data_T_2A(j,2))/(data_T_2A(j+1,1)-data_T_2A(j,1));
end

for j = 1:82-1
    data_temp_deriv_4A(j) = (data_T_4A(j+1,2)-data_T_4A(j,2))/(data_T_4A(j+1,1)-data_T_4A(j,1));
end

for j = 1:82-1
    data_temp_deriv_6A(j) = (data_T_6A(j+1,2)-data_T_6A(j,2))/(data_T_6A(j+1,1)-data_T_6A(j,1));
end

for j = 1:75-1
    data_temp_deriv_8A(j) = (data_T_8A(j+1,2)-data_T_8A(j,2))/(data_T_8A(j+1,1)-data_T_8A(j,1));
end

for j = 1:80-1
    data_temp_deriv_10A(j) = (data_T_10A(j+1,2)-data_T_10A(j,2))/(data_T_10A(j+1,1)-data_T_10A(j,1));
end


end