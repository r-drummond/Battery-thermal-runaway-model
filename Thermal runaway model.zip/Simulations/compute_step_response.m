function [T_step] = compute_step_response(params)

nQ = 6e3;T_step = zeros(nQ,5);
Q_space = linspace(0,params.Qmax,nQ);
I_space = [2,4,6,8,10];

p_step = 0.9e-2; a_step = 1*1*p_step; a_cap = 2e-3;
for g = 1:max(size(I_space))
    for j = 1:nQ
        time_step = Q_space(j)/I_space(g);
        T_step(j,g) = a_step*(I_space(g)/p_step)*(1-exp(-p_step*time_step)) + 1*a_cap*Q_space(j);
    end
end

end