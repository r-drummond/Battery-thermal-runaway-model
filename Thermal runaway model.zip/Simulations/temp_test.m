function [x_dot] = temp_test(states,I,params,mats,Tamb)

%% Define the parameters for the piece-wise polynomial approximation of the OCV
z_vec = [0,0.06407,0.1822,0.2883,0.6233,0.8,0.9419,0.994,1];
p = [2.62; 3.1373;  3.4394;  3.5388; 3.814;3.966;4.0752; 4.1322;4.2531];
c1 = p(1); c2 = p(2); c3 = p(3); c4 = p(4); c5 = p(5);  c6 = p(6); c7 = p(7); c8 = p(8);
b1 = 1/1.3; b2 = 1/1.65; b3 = 1; b4 = 1.2; b5 = 1.2; b6 = 0.8; b7 = 3; b8 = 1;
a1 = (p(2)-p(1))/(z_vec(2))^b1; a2 = (p(3)-p(2))/(z_vec(3)-z_vec(2))^b2; a3 = (p(4)-p(3))/(z_vec(4)-z_vec(3))^b3; a4 = (p(5)-p(4))/(z_vec(5)-z_vec(4))^b4; a5 = (p(6)-p(5))/(z_vec(6)-z_vec(5))^b5; a6 = (p(7)-p(6))/(z_vec(7)-z_vec(6))^b6;a7 = (p(8)-p(7))/(z_vec(8)-z_vec(7))^b7; a8 = (p(9)-p(8))/(z_vec(9)-z_vec(8))^b8;

w_sum = zeros(params.par_num,1); soc = zeros(params.par_num,1);  OCV = zeros(params.par_num,1); w = zeros(params.par_num,params.series_num);

for j = 1:params.par_num
    soc(j) = states((j-1)*(params.series_num*2)+1);
    
    if soc(j)<=z_vec(2)
        OCV_init = a1*(soc)^b1+c1;
    elseif soc(j)>=z_vec(2) && soc(j)<=z_vec(3)
        OCV_init = a2*(soc(j)-z_vec(2))^b2+c2;
    elseif soc(j)>=z_vec(3) && soc(j)<=z_vec(4)
        OCV_init = a3*(soc(j)-z_vec(3))^b3+c3;
    elseif soc(j)>=z_vec(4) && soc(j)<=z_vec(5)
        OCV_init = a4*(soc(j)-z_vec(4))^b4+c4;
    elseif soc(j)>=z_vec(5) && soc(j)<=z_vec(6)
        OCV_init = a5*(soc(j)-z_vec(5))^b5+c5;
    elseif soc(j)>=z_vec(6) && soc(j)<=z_vec(7)
        OCV_init = a6*(soc(j)-z_vec(6))^b6+c6;
    elseif soc(j)>=z_vec(7) && soc(j)<=z_vec(8)
        OCV_init = a7*(soc(j)-z_vec(7))^b7+c7;
    elseif soc(j)>=z_vec(8) && soc(j)<=z_vec(9)
        OCV_init = a8*(soc(j)-z_vec(8))^b8+c8;
    else
        OCV_init = 0;
    end
    
    OCV(j) = OCV_init;
    for i = 1:params.series_num
        w(j,i) = states((j-1)*(params.series_num*2)+i);
        w_sum(j) = w_sum(j) + w(j,i);
    end
end

i_branch = (1/params.par_num)*ones(params.par_num,1)*I;

%%
% A_temp = mats.Tinv_sections\mat_lin; % The A matrix of the temperature dynamics.
% B_temp = mats.Tinv_sections\[heat_rates, mats.ambient_term,mats.ambient_term_quad,Tsurf']; % The B matrix of the temperature dynamics. % have to add the radiation ambient effetcs too


x_dot = mats.A_temp*states +  mats.B_temp*[params.R_par.*i_branch.^2;Tamb;Tamb^4;(mats.Tsurf*states)];

end




















