function OCV = compute_OCV(z)

%% This function uses a piece-wise polynmial approximation of theopen circuit voltage.

nz = max(size(z));

%% from datasheet #2
z_vec = [0,0.06407,0.1822,0.2883,0.6233,0.8,0.9419,0.994,1];
p = [2.62; 3.1373;  3.4394;  3.5388; 3.814;3.966;4.0752; 4.1322;4.2531];

c1 = p(1); c2 = p(2); c3 = p(3); c4 = p(4); c5 = p(5);  c6 = p(6); c7 = p(7); c8 = p(8);

b1 = 1/1.3; b2 = 1/1.65; b3 = 1; b4 = 1.2; b5 = 1.2; b6 = 0.8; b7 = 3; b8 = 1;
a1 = (p(2)-p(1))/(z_vec(2))^b1; a2 = (p(3)-p(2))/(z_vec(3)-z_vec(2))^b2; a3 = (p(4)-p(3))/(z_vec(4)-z_vec(3))^b3; a4 = (p(5)-p(4))/(z_vec(5)-z_vec(4))^b4; a5 = (p(6)-p(5))/(z_vec(6)-z_vec(5))^b5; a6 = (p(7)-p(6))/(z_vec(7)-z_vec(6))^b6;a7 = (p(8)-p(7))/(z_vec(8)-z_vec(7))^b7; a8 = (p(9)-p(8))/(z_vec(9)-z_vec(8))^b8;

OCV = zeros(nz,1);

for j = 1:nz
    if z(j)<=z_vec(2)
        OCV_init = a1*(z(j))^b1+c1;
    elseif z(j)>=z_vec(2) && z(j)<=z_vec(3)
        OCV_init = a2*(z(j)-z_vec(2))^b2+c2;
    elseif z(j)>=z_vec(3) && z(j)<=z_vec(4)
        OCV_init = a3*(z(j)-z_vec(3))^b3+c3;
    elseif z(j)>=z_vec(4) && z(j)<=z_vec(5)
        OCV_init = a4*(z(j)-z_vec(4))^b4+c4 + 0*2e-2*sin(2*pi*(z_vec(5)-z(j))/(z_vec(5)-z_vec(4)));
    elseif z(j)>=z_vec(5) && z(j)<=z_vec(6)
        OCV_init = a5*(z(j)-z_vec(5))^b5+c5 +0*2e-2*sin(2*pi*(z_vec(6)-z(j))/(z_vec(6)-z_vec(5)));
    elseif z(j)>=z_vec(6) && z(j)<=z_vec(7)
        OCV_init = a6*(z(j)-z_vec(6))^b6+c6;
    elseif z(j)>=z_vec(7) && z(j)<=z_vec(8)
        OCV_init = a7*(z(j)-z_vec(7))^b7+c7;
    elseif z(j)>=z_vec(8) && z(j)<=z_vec(9)
        OCV_init = a8*(z(j)-z_vec(8))^b8+c8;
    else
        OCV_init = 0;
    end
    OCV(j) = OCV_init;
end

end
