function [soc_pack, Tc_pack,Tm_pack,Ts_pack] = run_simulation_pack(mats,params,x0_pack)

z_vec = [0,0.06407,0.1822,0.2883,0.6233,0.8,0.9419,0.994,1];
p = [2.62; 3.1373;  3.4394;  3.5388; 3.814;3.966;4.0752; 4.1322;4.2531];
c1 = p(1); c2 = p(2); c3 = p(3); c4 = p(4); c5 = p(5);  c6 = p(6); c7 = p(7); c8 = p(8);
b1 = 1/1.3; b2 = 1/1.65; b3 = 1; b4 = 1.2; b5 = 1.2; b6 = 0.8; b7 = 3; b8 = 1;
a1 = (p(2)-p(1))/(z_vec(2))^b1; a2 = (p(3)-p(2))/(z_vec(3)-z_vec(2))^b2; a3 = (p(4)-p(3))/(z_vec(4)-z_vec(3))^b3; a4 = (p(5)-p(4))/(z_vec(5)-z_vec(4))^b4; a5 = (p(6)-p(5))/(z_vec(6)-z_vec(5))^b5; a6 = (p(7)-p(6))/(z_vec(7)-z_vec(6))^b6;a7 = (p(8)-p(7))/(z_vec(8)-z_vec(7))^b7; a8 = (p(9)-p(8))/(z_vec(9)-z_vec(8))^b8;


%% Thermal and electrical simulation of the whole pack
n_t_obs = 3e3; end_frac = 0.8;
Iapp = params.Iavg*params.par_num;  tf =end_frac*params.Qmax*params.par_num/abs(Iapp); tspan = linspace(0,tf,n_t_obs );
[t_pack,states_pack] = ode15s(@(t_pack,states_pack)pack_test(states_pack,Iapp ,params,mats),tspan,x0_pack); % Simulate the thermal runaway dynamics
soc_pack = zeros(max(size(t_pack)),params.n_cells); Ts_pack = zeros(max(size(t_pack)),params.n_cells); Tm_pack = zeros(max(size(t_pack)),params.n_cells); Tc_pack = zeros(max(size(t_pack)),params.n_cells);
i_branch = zeros(n_t_obs,params.par_num); w_sum = zeros(n_t_obs,params.par_num); w_sum_par = zeros(n_t_obs,params.par_num); OCV_sum_par = zeros(n_t_obs,params.par_num);


for j = 1:params.n_cells
    soc_pack(:,j) = states_pack(:,(j-1)*params.n_elec+1);
    Ts_pack(:,j) = states_pack(:,params.n_elec*params.n_cells+(j-1)*3+1);
    Tm_pack(:,j) = states_pack(:,params.n_elec*params.n_cells+(j-1)*3+2);
    Tc_pack(:,j) = states_pack(:,params.n_elec*params.n_cells+(j-1)*3+3);
    %     i_branch(:,j) = -(mats.Pi_ocv*(w_sum(:,j) +OCV_sum_par)+ mats.Pi_I*Iapp);
end

for g = 1:n_t_obs
    for j = 1:params.n_cells
        soc = max([soc_pack(g,j),0]);
        
        if soc<=z_vec(2)
            OCV_init = a1*(soc)^b1+c1;
        elseif soc>=z_vec(2) && soc<=z_vec(3)
            OCV_init = a2*(soc-z_vec(2))^b2+c2;
        elseif soc>=z_vec(3) && soc<=z_vec(4)
            OCV_init = a3*(soc-z_vec(3))^b3+c3;
        elseif soc>=z_vec(4) && soc<=z_vec(5)
            OCV_init = a4*(soc-z_vec(4))^b4+c4;
        elseif soc>=z_vec(5) && soc<=z_vec(6)
            OCV_init = a5*(soc-z_vec(5))^b5+c5;
        elseif soc>=z_vec(6) && soc<=z_vec(7)
            OCV_init = a6*(soc-z_vec(6))^b6+c6;
        elseif soc>=z_vec(7) && soc<=z_vec(8)
            OCV_init = a7*(soc-z_vec(7))^b7+c7;
        elseif soc>=z_vec(8) && soc<=z_vec(9)
            OCV_init = a8*(soc-z_vec(8))^b8+c8;
        else
            OCV_init = 0;
        end
        
        OCV(j) = OCV_init;
        
        w_sum(g,j) = sum(states_pack(g,(j-1)*params.n_elec+2:(j-1)*params.n_elec+1+params.nw));
    end
    counter = 1;
    for j = 1:params.par_num
        for i = 1:params.series_num
            w_sum_par(g,j) = w_sum_par(g,j)+w_sum(counter); OCV_sum_par(g,j) = OCV_sum_par(g,j)+OCV(counter);
            counter = counter+1;
        end
        
    end
    i_branch(g,:) = (mats.Pi_ocv*(w_sum_par(g,:)' +OCV_sum_par(g,:)')- mats.Pi_I*Iapp)';
end



%% Plot the results
colour_AC = 0.9*[1,1,1]; marker_size = 12; line_width = 2; f_size = 12;
fig_temp_pack = figure;
plot(t_pack,Ts_pack(:,1)'-273,'color',0.2*colour_AC,'LineWidth',2,'linestyle','-'); hold on;
plot(t_pack,Ts_pack(:,2)'-273,'color',0.5*colour_AC,'LineWidth',2,'linestyle','-'); hold on;
plot(t_pack,Tm_pack(:,1)'-273,'color','b','LineWidth',2,'linestyle','--'); hold on;
plot(t_pack,Tc_pack(:,1)'-273,'color','r','LineWidth',2,'linestyle','-.'); hold on;
xlabel('Charging time (s)','interpreter','latex','fontsize',f_size,'interpreter','latex')
ylabel('Temperature $^o$C','interpreter','latex','fontsize',f_size,'interpreter','latex')
grid on
leg = legend('Surface (cell 1)','Surface (cell 2)','Mid (cell 1)','Core (cell 1)');
set(leg,'interpreter','latex','fontsize',14,'location','southeast')
set(gca,'FontSize',14);


txt_all = ['Cell = ',num2str(1),' '];
for j = 2:params.n_cells
    if j <= 9
    txt_all = [txt_all;'Cell = ',num2str(j),' '];
    else
        txt_all = [txt_all;'Cell = ',num2str(j)];
    end
end


fig_temp_pack2 = figure;
for j = 1:params.n_cells
    plot(t_pack,Ts_pack(:,j)'-273,'color',((j-1)/params.n_cells)*colour_AC,'LineWidth',2,'linestyle','-'); hold on;
end
xlabel('Charging time (s)','interpreter','latex','fontsize',f_size,'interpreter','latex')
ylabel('Various cell surface temperatures in the pack $^o$C','interpreter','latex','fontsize',f_size,'interpreter','latex')
grid on
set(gca,'FontSize',14);
leg = legend(txt_all);
set(leg,'interpreter','latex','fontsize',12,'location','eastoutside')



fig_soc_pack2 = figure;
for j = 1:params.n_cells
    plot(t_pack,soc_pack(:,j)','color',((j-1)/params.n_cells)*colour_AC,'LineWidth',2,'linestyle','-'); hold on;
end
xlabel('Charging time (s)','interpreter','latex','fontsize',f_size,'interpreter','latex')
ylabel('SoC distribution across the pack','interpreter','latex','fontsize',f_size,'interpreter','latex')
grid on
set(gca,'FontSize',14);
leg = legend(txt_all);
set(leg,'interpreter','latex','fontsize',12,'location','eastoutside')

txt_brnch = ['Branch = ',num2str(1)];
for j = 2: params.par_num
    txt_brnch = [txt_brnch;'Branch = ',num2str(j)];
end

fig_i_branch = figure;
for j = 1:params.par_num
    plot(t_pack,i_branch(:,j)','color',((j-1)/params.par_num)*colour_AC,'LineWidth',2,'linestyle','-'); hold on;
end
xlabel('Charging time (s)','interpreter','latex','fontsize',f_size,'interpreter','latex')
ylabel('Parallel branch current (A)','interpreter','latex','fontsize',f_size,'interpreter','latex')
grid on
set(gca,'FontSize',14);
leg = legend(txt_brnch);
set(leg,'interpreter','latex','fontsize',12,'location','southwest')

% print(fig_temp_pack  ,'temp','-depsc')
% print(fig_temp_pack2  ,'temp2','-depsc')
% print(fig_soc_pack2  ,'soc','-depsc')
% print(fig_i_branch  ,'i_branch','-depsc')

print(fig_temp_pack  ,'temp_other','-depsc')
print(fig_temp_pack2  ,'temp2_other','-depsc')
print(fig_soc_pack2  ,'soc_other','-depsc')
print(fig_i_branch  ,'i_branch_other','-depsc')


end