function [x_dot] = run_TR_sim(params,mats,x0_TR0,arc1,arc2)

%%
TR_Tsurf_vec = zeros(params.n_cells,params.n_TR*params.n_cells);TR_Tmid_vec = zeros(params.n_cells,params.n_TR*params.n_cells); TR_Tcore_vec = zeros(params.n_cells,params.n_TR*params.n_cells); TR_Z_vec = zeros(params.n_cells,params.n_TR*params.n_cells);
xs_c_vec = zeros(params.n_cells,params.n_TR*params.n_cells); xs_m_vec = zeros(params.n_cells,params.n_TR*params.n_cells); xs_s_vec = zeros(params.n_cells,params.n_TR*params.n_cells);
xa_c_vec = zeros(params.n_cells,params.n_TR*params.n_cells); xa_m_vec = zeros(params.n_cells,params.n_TR*params.n_cells); xa_s_vec = zeros(params.n_cells,params.n_TR*params.n_cells);
z_c_vec = zeros(params.n_cells,params.n_TR*params.n_cells); z_m_vec = zeros(params.n_cells,params.n_TR*params.n_cells); z_s_vec = zeros(params.n_cells,params.n_TR*params.n_cells);
alpha_c_vec = zeros(params.n_cells,params.n_TR*params.n_cells); alpha_m_vec = zeros(params.n_cells,params.n_TR*params.n_cells); alpha_s_vec = zeros(params.n_cells,params.n_TR*params.n_cells);

for j = 1:params.n_cells
    x0_TR(params.n_TR*(j)-(params.n_TR-1):params.n_TR*(j),1) = x0_TR0; % Initial conditions of the thermal runaway pack model.
    TR_Tsurf_vec(j,(j-1)*params.n_TR+16) = 1; % Matrix to extract the surface temperatures of the cells in the thermal runaway pack model.
    TR_Tmid_vec(j,(j-1)*params.n_TR+15) = 1; % Matrix to extract the middle temperatures of the cells in the thermal runaway pack model.
    TR_Tcore_vec(j,(j-1)*params.n_TR+14) = 1; % Matrix to extract the core temperatures of the cells in the thermal runaway pack model.
    TR_Z_vec(j,(j-1)*params.n_TR+7) = 1;
    xs_c_vec(j,(j-1)*params.n_TR+1) = 1; xs_m_vec(j,(j-1)*params.n_TR+2) = 1; xs_s_vec(j,(j-1)*params.n_TR+3) = 1; % Matrices to extract the SEI decomposition in the core xs_c_vec, middle xs_m_vec and surfaces xs_s_vec of the cells.
    xa_c_vec(j,(j-1)*params.n_TR+4) = 1; xa_m_vec(j,(j-1)*params.n_TR+5) = 1; xa_s_vec(j,(j-1)*params.n_TR+6) = 1; % Matrices to extract the anode decomposition in the core xa_c_vec, middle xa_m_vec and surfaces xa_s_vec of the cells.
    z_c_vec(j,(j-1)*params.n_TR+8) = 1; z_m_vec(j,(j-1)*params.n_TR+9) = 1; z_s_vec(j,(j-1)*params.n_TR+10) = 1; % Matrices to extract the SEI thickness in the core z_c_vec, middle z_m_vec and surfaces z_s_vec of the cells.
    alpha_c_vec(j,(j-1)*params.n_TR+11) = 1; alpha_m_vec(j,(j-1)*params.n_TR+12) = 1; alpha_s_vec(j,(j-1)*params.n_TR+13) = 1; % Matrices to extract the cathode decomposition in the core alpha_c_vec, middle alpha_m_vec and surfaces alpha_s_vec of the cells.
end


%% This section tests the thermal runaway model via a matlab sim- matlab is a bit easier to simulate and debug than simulink I've found.
states = x0_TR; heater = [1;zeros(params.n_cells-1,1)]; z = 0.5*ones(params.n_cells); Tcore = params.Tamb*ones(params.n_cells);   Tmid = params.Tamb*ones(params.n_cells);  Tsurf =params.Tamb*ones(params.n_cells); Tamb = params.Tamb;
[x_dot] = TR_derivs_test3(states,heater,z,Tcore,Tmid,Tsurf,arc1, arc2,Tamb,mats,params); % test to see whether the thermal runaway dynamics have a bug

tf = 1e3; n_steps = 3*tf; tspan = linspace(0,tf,n_steps); % set up the simulation time.
[t_TR,states_TR] = ode15s(@(t_TR,states_TR)TR_derivs_test3(states_TR,heater,z,Tcore,Tmid,Tsurf,arc1, arc2,Tamb,mats,params),tspan,states); % Simulate the thermal runaway dynamics

nT = max(size(t_TR));
Tc = zeros(params.n_cells,nT);Tm = zeros(params.n_cells,nT);Ts = zeros(params.n_cells,nT);
xs_c = zeros(params.n_cells,nT); xs_m = zeros(params.n_cells,nT); xs_s = zeros(params.n_cells,nT);
xa_c = zeros(params.n_cells,nT);xa_m = zeros(params.n_cells,nT);xa_s = zeros(params.n_cells,nT);
z_c = zeros(params.n_cells,nT);z_m = zeros(params.n_cells,nT);  z_s = zeros(params.n_cells,nT); 
alpha_c = zeros(params.n_cells,nT);alpha_m = zeros(params.n_cells,nT);  alpha_s = zeros(params.n_cells,nT); 
soc = zeros(params.n_cells,nT);
for j = 1:nT  % extract the various states of the simulation to plot
    Tc(:,j) = TR_Tcore_vec*states_TR(j,:)'; Tm(:,j) = TR_Tmid_vec*states_TR(j,:)'; Ts(:,j) = TR_Tsurf_vec*states_TR(j,:)';
    xs_c(:,j) =  xs_c_vec*states_TR(j,:)'; xs_m(:,j) =  xs_m_vec*states_TR(j,:)'; xs_s(:,j) =  xs_s_vec*states_TR(j,:)';
    xa_c(:,j) = xa_c_vec*states_TR(j,:)'; xa_m(:,j) = xa_m_vec*states_TR(j,:)'; xa_s(:,j) = xa_s_vec*states_TR(j,:)';
    z_c(:,j) = z_c_vec*states_TR(j,:)'; z_m(:,j) = z_m_vec*states_TR(j,:)'; z_s(:,j) = z_m_vec*states_TR(j,:)';
    alpha_c(:,j) = alpha_c_vec*states_TR(j,:)'; alpha_m(:,j) = alpha_m_vec*states_TR(j,:)'; alpha_s(:,j) = alpha_s_vec*states_TR(j,:)';
    soc(:,j) =  TR_Z_vec*states_TR(j,:)';
end

%% This section plots the state trajectories of the model simulation above.
% close all
f_size= 14;  colour_3 = [0.6 0.6 0.6];
colour_4 = 0.5*[1 1 1];
colour0 = 0.9*[1 1 1];
f_size_leg= 12;

fig1 = figure;
colour = (1/params.n_cells)*colour0;
plot(t_TR,Tc(1,:),'k','linewidth',2,'color',colour); hold on;
for j = 2:params.n_cells
    colour = (j/params.n_cells)*colour0;
    plot(t_TR,Tc(j,:),'k','linewidth',2,'color',colour);
end
plot(t_TR,params.isc_temp*ones(max(size(t_TR))),'-r','linewidth',1); hold on;
plot(t_TR,params.Tsep_fail*ones(max(size(t_TR))),'-.r','linewidth',1); hold on;
grid on;
xlabel('$t$ (s)','fontSize',f_size,'interpreter','latex')
ylabel('Core temperature (K)','fontSize',f_size,'interpreter','latex')
leg = legend('Cell 1','Cell 2','Cell 3','Cell 4','Trigger','Separator degrades');
set(leg,'interpreter','latex','fontsize',f_size_leg,'location','southeast')


fig2 = figure;
colour = (1/params.n_cells)*colour0;
plot(t_TR,Tm(1,:),'k','linewidth',2,'color',colour); hold on;
for j = 2:params.n_cells
    colour = (j/params.n_cells)*colour0;
    plot(t_TR,Tm(j,:),'k','linewidth',2,'color',colour);
end
plot(t_TR,params.Tsep_fail*ones(max(size(t_TR))),'-.r','linewidth',1); hold on;
grid on;
xlabel('$t$ (s)','fontSize',f_size,'interpreter','latex')
ylabel('Middle temperature (K)','fontSize',f_size,'interpreter','latex')
leg = legend('Cell 1','Cell 2','Cell 3','Cell 4','Separator degrades');
set(leg,'interpreter','latex','fontsize',f_size_leg,'location','southeast')


fig3 = figure;
colour = (1/params.n_cells)*colour0;
plot(t_TR,Ts(1,:),'k','linewidth',2,'color',colour); hold on;
for j = 2:params.n_cells
    colour = (j/params.n_cells)*colour0;
    plot(t_TR,Ts(j,:),'k','linewidth',2,'color',colour);
end
plot(t_TR,params.Tsep_fail*ones(max(size(t_TR))),'-.r','linewidth',1); hold on;
grid on;
xlabel('$t$ (s)','fontSize',f_size,'interpreter','latex')
ylabel('Surface temperature (K)','fontSize',f_size,'interpreter','latex')
leg = legend('Cell 1','Cell 2','Cell 3','Cell 4','Separator degrades');
set(leg,'interpreter','latex','fontsize',f_size_leg,'location','southeast')

fig_single = figure;
plot(t_TR,Tc(1,:),'k','linewidth',2,'color',0.9*[1 1 1]); hold on;
plot(t_TR,Tm(1,:),'k','linewidth',2,'color',0.6*[1 1 1]);
plot(t_TR,Ts(1,:),'k','linewidth',2,'color',0.4*[1 1 1]);
plot(t_TR,params.isc_temp*ones(max(size(t_TR))),'-r','linewidth',1); hold on;
plot(t_TR,params.Tsep_fail*ones(max(size(t_TR))),'-.r','linewidth',1); hold on;
grid on;
xlabel('$t$ (s)','fontSize',f_size,'interpreter','latex')
ylabel('Temperature (K)','fontSize',f_size,'interpreter','latex')
leg = legend('Core','Middle','Surface','Cell 4','Trigger','Separator degrades');
set(leg,'interpreter','latex','fontsize',f_size_leg,'location','southeast')



fig4 = figure;
plot(t_TR,xs_c(1,:),'k','linewidth',2); hold on;
plot(t_TR,xa_c(1,:),'b','linewidth',2); hold on;
plot(t_TR,z_c(1,:),'r','linewidth',2); hold on;
plot(t_TR,alpha_c(1,:),'k','linewidth',2,'color',0.5*[1 1 1]); hold on;
plot(t_TR,soc(1,:),'r','linewidth',2,'color',0.7*[1 1 1]); hold on;
grid on;
xlabel('$t$ (s)','fontSize',f_size,'interpreter','latex')
ylabel('Degradation (core)','fontSize',f_size,'interpreter','latex')
leg = legend('$x_s$ (core)','$x_a$ (core)','$z$ (core)','$\alpha$ (core)','SoC');
set(leg,'interpreter','latex','fontsize',f_size_leg,'location','east');




fig5 = figure;
plot(t_TR,xs_m(1,:),'k','linewidth',2); hold on;
plot(t_TR,xa_m(1,:),'b','linewidth',2); hold on;
plot(t_TR,z_m(1,:),'r','linewidth',2); hold on;
plot(t_TR,alpha_m(1,:),'k','linewidth',2,'color',0.5*[1 1 1]); hold on;
plot(t_TR,soc(1,:),'r','linewidth',2,'color',0.7*[1 1 1]); hold on;
grid on;
xlabel('$t$ (s)','fontSize',f_size,'interpreter','latex')
ylabel('Degradation (middle)','fontSize',f_size,'interpreter','latex')
leg = legend('$x_s$ (mid)','$x_a$ (mid)','$z$ (mid)','$\alpha$ (mid)','SoC');
set(leg,'interpreter','latex','fontsize',f_size_leg,'location','east');



fig6 = figure;
plot(t_TR,xs_s(1,:),'k','linewidth',2); hold on;
plot(t_TR,xa_s(1,:),'b','linewidth',2); hold on;
plot(t_TR,z_s(1,:),'r','linewidth',2); hold on;
plot(t_TR,alpha_s(1,:),'k','linewidth',2,'color',0.5*[1 1 1]); hold on;
plot(t_TR,soc(1,:),'r','linewidth',2,'color',0.7*[1 1 1]); hold on;
grid on;
xlabel('$t$ (s)','fontSize',f_size,'interpreter','latex')
ylabel('Degradation (surface)','fontSize',f_size,'interpreter','latex')
leg = legend('$x_s$ (surf)','$x_a$ (surf)','$z$ (surf)','$\alpha$ (surf)','SoC');
set(leg,'interpreter','latex','fontsize',f_size_leg,'location','east');

fig7 = figure;
plot(t_TR,xa_c(1,:),'b','linewidth',2,'color',0.9*[1 1 1]); hold on;
plot(t_TR,xa_m(1,:),'b','linewidth',2,'color',0.7*[1 1 1]); hold on;
plot(t_TR,xa_s(1,:),'b','linewidth',2,'color',0.5*[1 1 1]); hold on;
grid on;
xlabel('$t$ (s)','fontSize',f_size,'interpreter','latex')
ylabel('Ande degredation','fontSize',f_size,'interpreter','latex')
leg = legend('Core','Middle','Surface');
set(leg,'interpreter','latex','fontsize',f_size_leg,'location','northeast');


% print(fig3,'error_all','-depsc')

end