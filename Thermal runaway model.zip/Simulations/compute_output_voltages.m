function [Pi_ocv,Pi_I] = compute_output_voltages(n,~,mats,params)
    
%% This function alows the currents of each parallel branch to be computed from the OCV, the relaxation voltages and pack current.

%%
n = params.par_num; % The number of parallel branches
R= params.R_par; % The resistances of each paralel branch.

m = zeros(n,n);
Rsum_inv = sum(1./R);

for ktil = 1:n
    for i = 1:n-1
        if ktil - i-1 == 0
            m(i+1,i) = (1/R(i+1))^2*(1/Rsum_inv)-1/R(i+1);
        else
            m(ktil,i) = (1/(R(ktil)*R(i+1)))/Rsum_inv;
        end
    end
end

m(n,n) = 1/(R(n)*Rsum_inv );

for i = 1:n-1
    m(i,n)= 1/(R(i)*Rsum_inv );
end

m_sum = zeros(n,1);
for i = 1:n
    m_sum(i) = sum(m(i,1:n-1));
end

Mat = [m_sum,-m(:,1:n-1)]; 

%%
Pi_ocv = -Mat; % matrix mapping OCV+w to the parallel branch currents
Pi_I = -m(:,n); % matrix mapping the applied pack current to the parallel branch currents





end












