function x_dot  = TR_test_new( states,heater,t,mats,params)


% This function establishes the dynamics of the thermal runaway  simulations.

%% Initialise the sizes of some vectors.
x_dot = 0*states;
x_dot_init= 0*states;
temp_balance_terms = 0*states;

%% Define the parameters for the piece-wise polynomial approximation of the OCV
z_vec = [0,0.06407,0.1822,0.2883,0.6233,0.8,0.9419,0.994,1];
p = [2.62; 3.1373;  3.4394;  3.5388; 3.814;3.966;4.0752; 4.1322;4.2531];
c1 = p(1); c2 = p(2); c3 = p(3); c4 = p(4); c5 = p(5);  c6 = p(6); c7 = p(7); c8 = p(8);
b1 = 1/1.3; b2 = 1/1.65; b3 = 1; b4 = 1.2; b5 = 1.2; b6 = 0.8; b7 = 3; b8 = 1;
a1 = (p(2)-p(1))/(z_vec(2))^b1; a2 = (p(3)-p(2))/(z_vec(3)-z_vec(2))^b2; a3 = (p(4)-p(3))/(z_vec(4)-z_vec(3))^b3; a4 = (p(5)-p(4))/(z_vec(5)-z_vec(4))^b4; a5 = (p(6)-p(5))/(z_vec(6)-z_vec(5))^b5; a6 = (p(7)-p(6))/(z_vec(7)-z_vec(6))^b6;a7 = (p(8)-p(7))/(z_vec(8)-z_vec(7))^b7; a8 = (p(9)-p(8))/(z_vec(9)-z_vec(8))^b8;

%% Establish some parameters

% Masses
core_ratio= params.core_ratio;  m_ratio=params.mid_ratio;
surface_ratio=1-params.mid_ratio-params.core_ratio;
ma= params.ma;
mc= params.mc;

mass_core= params.m_core;
mass_m= params.m_mid;
mass_surface= params.m_surf;
ma_core= params.ma*params.core_ratio;
ma_m= params.ma*params.mid_ratio;
ma_surface=ma*(1-params.core_ratio-params.mid_ratio);
mc_core= params.mc*params.core_ratio;
mc_m= params.mc*params.mid_ratio;
mc_surface=mc*(1-params.core_ratio-params.mid_ratio);

%% Resolve the various currents and resistances of the model.

counter = 1; U_resolve= zeros(params.n_cells,1);
R_core= zeros(params.n_cells,1); R_mid= zeros(params.n_cells,1); R_surf= zeros(params.n_cells,1); current_short_trigger = zeros(params.n_cells,1); current_short_core = zeros(params.n_cells,1); current_short_mid = zeros(params.n_cells,1); current_short_surf = zeros(params.n_cells,1);  resistance_short_par= zeros(params.n_cells,1); current_short_soc = zeros(params.n_cells,1);
short = zeros(params.n_cells,1); short_trigger = zeros(params.n_cells,1);  short_sep_core = zeros(params.n_cells,1); short_sep_mid = zeros(params.n_cells,1); short_sep_surf = zeros(params.n_cells,1);

for i = 1:params.par_num
    for g = 1:params.series_num
        x = states((counter-1)*params.n_TR+1:counter*params.n_TR);
        Tc = x(14);  Tm = x(15);  Ts = x(16);
        xa_c = x(4); xa_m = x(5); xa_s = x(6);
        
        %% Define the temperature dependent resistances
        if heater(counter) ==1
            R_core(counter) = 3*params.R_vec(counter)*exp(params.Tref/Tc)/(exp(params.Tref/params.Tamb))+params.R_short_trigger; % Electrical resistances of the core + short. Varies with temperature.
        else
            R_core(counter) = 3*params.R_vec(counter)*exp(params.Tref/Tc)/(exp(params.Tref/params.Tamb)); % Electrical resistances of the cell cores. Varies with temperature.
        end
        R_mid(counter) = 3*params.R_vec(counter)*exp(params.Tref/Tm)/(exp(params.Tref/params.Tamb)); % Electrical resistances of the cell middles. Varies with temperature.
        R_surf(counter) = 3*params.R_vec(counter)*exp(params.Tref/Ts)/(exp(params.Tref/params.Tamb)); % Electrical resistances of the cell surfaces. Varies with temperature.
        
        %% Compute the open circuit voltages
        soc = x(7)*(x(7)>0)*(x(7)<=1);

        if soc<=z_vec(2)
            OCV_init = a1*(soc)^b1+c1;
        elseif soc>=z_vec(2) && soc<=z_vec(3)
            OCV_init = a2*(soc-z_vec(2))^b2+c2;
        elseif soc>=z_vec(3) && soc<=z_vec(4)
            OCV_init = a3*(soc-z_vec(3))^b3+c3;
        elseif soc>=z_vec(4) && soc<=z_vec(5)
            OCV_init = a4*(soc-z_vec(4))^b4+c4;
        elseif soc>=z_vec(5) && soc<=z_vec(6)
            OCV_init = a5*(soc-z_vec(5))^b5+c5;
        elseif soc>=z_vec(6) && soc<=z_vec(7)
            OCV_init = a6*(soc-z_vec(6))^b6+c6;
        elseif soc>=z_vec(7) && soc<=z_vec(8)
            OCV_init = a7*(soc-z_vec(7))^b7+c7;
        elseif soc>=z_vec(8) && soc<=z_vec(9)
            OCV_init = a8*(soc-z_vec(8))^b8+c8;
        else
            OCV_init = 0;
        end
        
        U_resolve(counter) = OCV_init;
        
        %% Compute the short circuit currents
        short_trigger(g) = (xa_c>0)*(Tc>params.isc_temp); % Switch to see if the trigger has been activated.
        short_sep_core(g) = (xa_c>0)*(Tc>params.Tsep_fail); % Switch to see if the short caused by the separator melting in the cell core is active.
        short_sep_mid(g) = (xa_m>0)*(Tm>params.Tsep_fail); % Switch to see if the short caused by the separator melting in the cell middle is active.
        short_sep_surf(g) = (xa_s>0)*(Ts>params.Tsep_fail); % Switch to see if the short caused by the separator melting in the cell surface is active.
        short(g) = (soc<=1)*(soc>0)*max([short_trigger(g),short_sep_core(g),short_sep_mid(g),short_sep_surf(g)]);  % Switch to see if any short circuit has occurred. 
        
        current_short_trigger(counter) = heater(counter)*short_trigger(g)*U_resolve(counter)/params.R_short_trigger; % Compute the short current caused by the trigger.
        current_short_core(counter) = short_sep_core(g)*U_resolve(counter)/params.R_short; % Compute the short current from the separator burning in the core.
        current_short_mid(counter) = short_sep_mid(g)*U_resolve(counter)/params.R_short; % Compute the short current from the separator burning in the core.
        current_short_surf(counter) = short_sep_surf(g)*U_resolve(counter)/params.R_short; % Compute the short current from the separator burning in the core.
        
        if short(g) >0
            resistance_short_par(g) = (short_trigger(g)/params.R_short_trigger+short_sep_core(g)/params.R_short+short_sep_mid(g)/params.R_short+short_sep_surf(g)/params.R_short)^(-1); % Compute the short circuit reisstance.
            current_short_soc(counter) = short(g)*U_resolve(counter)/resistance_short_par(g);   % Short circuit current. 
        else
            current_short_soc(counter) = 0; resistance_short_par(g) =  0; % Set short current and reisstance to zero if there is no short.
        end

        counter = counter+1;
    end
end

%% This bit allows the state to propogate around the initial equilibrium
% x0_TR_out = zeros(n*n_TR,1);
mat_Ts = zeros(params.n_cells*params.n_TR,params.n_cells); mat_Tc = zeros(params.n_cells*params.n_TR,params.n_cells); Ts_TR = zeros(params.n_cells,1); Tc_TR = zeros(params.n_cells,1);

for g = 1:params.n_cells
%     xs_core = x0_TR(1);  xs_m = x0_TR(2); xs_surface = x0_TR(3); % fraction of Li in SEI layer
%     xa_core = x0_TR(4); xa_m = x0_TR(5); xa_surface = x0_TR(6); % fraction of Li in anode
%     SOC= z(g);
%     z_core = x0_TR(8); z_m = x0_TR(9); z_surface = x0_TR(10); % SEI thickness
%     alpha_core = x0_TR(11); alpha_m = x0_TR(12); alpha_surface= x0_TR(13);  % cathode decomposition
%     Tc= Tcore(g);Tm= Tmid(g); Ts= Tsurf(g);
%     Tfix= x0_TR(17);
    
    Tc_TR(g) = states((g-1)*params.n_TR+14);
    Ts_TR(g) = states((g-1)*params.n_TR+16);
    mat_Ts((g-1)*params.n_TR+16,g) = 1;
    mat_Tc((g-1)*params.n_TR+14,g) = 1;
%     x0_TR_out((g-1)*n_TR+1:g*n_TR,1) = [xs_core; xs_m; xs_surface; xa_core ; xa_m; xa_surface;  SOC; z_core; z_m ;z_surface; alpha_core; alpha_m ; alpha_surface;Tc; Tm; Ts; Tfix];
%     x0_TR_out((g-1)*n_TR+1:g*n_TR,1) = x0_TR_0;
end


%% This sections computes the time derivative of the thermal runaway dynamics.
max_heater = max(abs(heater)); % Deteremines whether a cell is being heated to induce thermal runaway or not.

if max_heater >=1
    for g= 1:params.n_cells
        %% Extract the states
        x = states((g-1)*params.n_TR+1:g*params.n_TR);
        
        xs_core = x(1); xs_m = x(2); xs_surface = x(3); % The degree of SEI layer decomposition.
        xa_core = x(4);  xa_m = x(5); xa_surface = x(6); % The degree of anode decomposition.
        SOC= x(7);
        z_core = x(8); z_m = x(9); z_surface = x(10); % The normalised SEI layer thickness.
        alpha_core = x(11);  alpha_m = x(12); alpha_surface= x(13); % The degree of cathode decomposition.
        Tc= x(14); Tm= x(15); Ts= x(16); % Cell temperatures in core, middle and surface.
        Tfix= x(17); % Temperature of the fixings.
        soc_min = min([xa_core,xa_m, xa_surface]);
        
        %% Is there a short circuit yet?
        ISC=Tc>params.isc_temp; % Short circuit is triggered when the core temperature goes above params.isc_temp.
        Q_heater= params.heater_power*heater(g)*(1-ISC)*(soc_min>0); % Shuts down the heater when the short circuit is initialised.
        
        %% Joule heating from the short circuit currents.
        Qec_core= (current_short_trigger(g)^2*params.R_short_trigger+current_short_core(g)^2*params.R_short); % Joule heating from short circuit. Stops when the SoC drops to zero.
        Qec_m = (current_short_mid(g)^2*params.R_short); % All the other currents are zero.
        Qec_surface = (current_short_surf(g)^2*params.R_short);
        
        %% Decomposition dynamics
        % The dynamics for SEI layer decmposition (core, middle and surface).
        xs_core_dot=-params.As*xs_core*exp(-params.Es/params.R_constant/Tc);
        xs_m_dot= -params.As*xs_m*exp(-params.Es/params.R_constant/Tm);
        xs_surface_dot= -params.As*xs_surface*exp(-params.Es/params.R_constant/Ts);
        
        % The dynamics for anode decmposition (core, middle and surface).        
        xa_core_dot= -params.Aa*xa_core*exp(-z_core/params.z0)*exp(-params.Ea/(params.R_constant*Tc));
        xa_m_dot= -params.Aa*xa_m*exp(-z_m/params.z0)*exp(-params.Ea/(params.R_constant*Tm));
        xa_surface_dot= -params.Aa*xa_surface*exp(-z_surface/params.z0)*exp(-params.Ea/(params.R_constant*Ts));
          
        xa_core_dot= xa_core_dot-short_sep_core(g)*(current_short_soc(g))/params.Qmax;
        xa_m_dot= xa_m_dot-short_sep_mid(g)*current_short_soc(g)/params.Qmax;
        xa_surface_dot= xa_surface_dot-short_sep_surf(g)*current_short_soc(g)/params.Qmax;
        
        % The dynamics for the normalised SEI layer thickness (core, middle and surface).
        z_core_dot=+params.Aa*xa_core*exp(-z_core/params.z0)*exp(-params.Ea/(params.R_constant*Tc));
        z_m_dot= params.Aa*xa_m*exp(-z_m/params.z0)*exp(-params.Ea/(params.R_constant*Tm));
        z_surface_dot= params.Aa*xa_surface*exp(-z_surface/params.z0)*exp(-params.Ea/(params.R_constant*Ts));
        
        % The dynamics for cathode decmposition (cre, middle and surface).
        alpha_core_dot=params.Ac*exp(-params.Ec/params.R_constant/Tc)*(1-alpha_core)*alpha_core;
        alpha_m_dot= params.Ac*exp(-params.Ec/params.R_constant/Tm)*(1-alpha_m)*alpha_m;
        alpha_surface_dot= params.Ac*exp(-params.Ec/params.R_constant/Ts)*(1-alpha_surface)*alpha_surface;
        
        %% Ensure that the decomposition only kicks in when the temperatures goes above a certain threshold.
        alpha_core_dot= alpha_core_dot*(Tc>params.cathode_degrade);  alpha_m_dot= alpha_m_dot*(Tm>params.cathode_degrade);  alpha_surface_dot= alpha_surface_dot*(Ts>params.cathode_degrade);
        z_core_dot= z_core_dot*(Tc>params.electrolyte_degrade);  z_m_dot= z_m_dot*(Tm>params.electrolyte_degrade);  z_surface_dot= z_surface_dot*(Ts>params.electrolyte_degrade);
        xa_core_dot=xa_core_dot*(Tc>params.electrolyte_degrade);  xa_m_dot= xa_m_dot*(Tm>params.electrolyte_degrade);  xa_surface_dot= xa_surface_dot*(Ts>params.electrolyte_degrade);
        xs_core_dot=  xs_core_dot*(Tc>params.SEI_degrade);  xs_m_dot= xs_m_dot*(Tm>params.SEI_degrade);  xs_surface_dot= xs_surface_dot*(Ts>params.SEI_degrade);
        
        %% State of charge drop- remove the soc dynamics!
        SOC_dot =-current_short_soc(g)/params.Qmax; % The state-of-charge drop caused by the short circuit.
        
        %% Get the heat generation rates
        Qa_core= -ma_core*params.ha*xa_core_dot;
        Qa_m= -ma_m*params.ha*xa_m_dot;
        Qa_surface= -ma_surface*params.ha*xa_surface_dot;
        Qc_core= mc_core*params.hc*alpha_core_dot;
        Qc_m= mc_m*params.hc*alpha_m_dot;
        Qc_surface= mc_surface*params.hc*alpha_surface_dot;
        Qs_core=-ma_core*params.hs*xs_core_dot;
        Qs_m=-ma_m*params.hs*xs_m_dot;
        Qs_surface=-ma_surface*params.hs*xs_surface_dot;
        
        %% Sum all the heat generation rates togetehr
        Qexo_core=Qa_core+Qc_core+Qs_core+Qec_core;
        Qexo_m=Qa_m+Qc_m+Qs_m+Qec_m;
        Qexo_surface=Qa_surface+Qc_surface+Qs_surface+Qec_surface;
        Q_hf=-params.Asurf*params.h*(Ts-Tfix);
        
        %% Add the heat transfer between the different layers
        Q_all_core=Qexo_core+0*(Q_heater*core_ratio)+(Tm-Tc)/params.r_m2c;
        Q_all_m=Qexo_m+0*Q_heater*m_ratio+(Tc-Tm)/params.r_m2c+(Ts-Tm)/params.r_m2s;
        Q_all_surface=Qexo_surface+Q_hf+Q_heater*surface_ratio+(Tm-Ts)/params.r_m2s ;
        
        Tc_dot=+Q_all_core/(mass_core*params.Cp);
        Tm_dot=+Q_all_m/(mass_m*params.Cp);
        Ts_dot=+Q_all_surface/(mass_surface*params.Cp);
        
        %% Account for the temperature change in the fixings.
        Qfix=(Tfix-params.Tamb)/ params.r_s2f;
        Tfix_dot=-(Qfix+Q_hf)/1.1016/910;
        
        %% Define the time derivative of the model.
        x_dot_init((g-1)*params.n_TR+1:g*params.n_TR) = [xs_core_dot;xs_m_dot;xs_surface_dot ;xa_core_dot;xa_m_dot;xa_surface_dot;SOC_dot;z_core_dot;z_m_dot;z_surface_dot;alpha_core_dot;alpha_m_dot;alpha_surface_dot;Tc_dot;Tm_dot;Ts_dot;Tfix_dot;0];
        
    end
end

%% Account ofr tabs jettising as cell erupts

jet = zeros(params.n_cells,1);
for j = 1:params.n_cells
    if Tc_TR(j) <= params.Tpop
        jet(j) = 1;
    end
end

counter = 1; connections_tabs = zeros(params.n_cells,params.n_cells); connections_tabs_front_bar = zeros(params.n_cells,params.n_cells);
for i = 1:params.par_num
    for j = 1:params.series_num
        for g = 1:params.series_num
            if j ~= g
                jet_min = min(jet((i-1)*params.series_num+g),jet((i-1)*params.series_num+j));
                connections_tabs((i-1)*params.series_num+g,(i-1)*params.series_num+g) = connections_tabs((i-1)*params.series_num+g,(i-1)*params.series_num+g) -1*jet_min/((abs(g-j))*params.spacing);
                connections_tabs((i-1)*params.series_num+j,(i-1)*params.series_num+g) = 1*jet_min/((abs(g-j))*params.spacing);
            end
        end
        counter = counter+1;
    end
    % This is the heat conduction associated with the front tab bar on the pack, that distributes the current across the parallel branches.
    for g = 1:params.par_num
        jet_min = min(jet((i-1)*params.series_num+1),jet((g-1)*params.series_num+1));
        if g~= i
            connections_tabs_front_bar((i-1)*params.series_num+1,(g-1)*params.series_num+1) = 1*jet_min/((abs(g-i))*params.spacing);
        end
        
    end
    connections_tabs_front_bar((i-1)*params.series_num+1,(i-1)*params.series_num+1) = -sum(connections_tabs_front_bar((i-1)*params.series_num+1,:));
end

mats.A_con_tabs = params.con_tab_param*(connections_tabs+connections_tabs_front_bar); % Matrix for the heat transfer between cells in the pack due to conduction.

%%
Tamb_vec = params.Tamb*ones(params.n_cells,1);

temp_balance_terms_cond =  mat_Ts*(mats.Tinv_surf\( mats.A_con*Ts_TR+mats.A_con_ambient_TR*(Tamb_vec-Ts_TR))); % Add the thermal interactions from the other cells.
temp_balance_terms_rad =  mat_Ts*(mats.Tinv_surf\(mats.A_rad*Ts_TR.^4 + mats.A_con_ambient_rad_TR*(Tamb_vec.^4-1*Ts_TR.^4))); % Add the thermal interactions from the other cells.
temp_balance_terms_tabs =  mat_Tc*(mats.Tinv_core\(mats.A_con_tabs*Tc_TR));

%%

sigma_vap = zeros(params.n_cells,1); mass_vapour = zeros(params.n_cells,1); mass_burn = zeros(params.n_cells,1);
for g= 1:params.n_cells
    %% Extract the states
    x = states((g-1)*params.n_TR+1:g*params.n_TR);
    
    xs_core = x(1); xs_m = x(2); xs_surface = x(3); % The degree of SEI layer decomposition.
    xa_core = x(4);  xa_m = x(5); xa_surface = x(6); % The degree of anode decomposition.
    SOC= x(7);
    z_core = x(8); z_m = x(9); z_surface = x(10); % The normalised SEI layer thickness.
    alpha_core = x(11);  alpha_m = x(12); alpha_surface= x(13); % The degree of cathode decomposition.
    Tc= x(14); Tm= x(15); Ts= x(16); % Cell temperatures in core, middle and surface.
    soc_min = min([xa_core,xa_m, xa_surface]);
    
    mass_vapour(g) = x(18);
    mass_burn(g)= xa_core;
    if mass_vapour(g) >= params.m_vap_lim && Ts >= params.T_ign
        sigma_vap(g,1) = 1;
    end
end

m_dot =  (params.theta_vap*mats.A_vap-params.theta_leak*eye(params.n_cells))*mass_vapour+mass_burn-sigma_vap*params.B_rate; %White vapour dynamics.
m_dot_scale = mats.m_vap_set*m_dot;
%%
temp_balance_terms= temp_balance_terms_cond+1*temp_balance_terms_rad+0*temp_balance_terms_tabs;
x_dot =  x_dot_init+ 1*temp_balance_terms;

x_dot = x_dot+m_dot_scale; % add the vapour dynamics. 

end




















