function [params,mats] = params_thermal(params,mats)
    
% Loads the parameters used for the thermal response of the battery pack model.  
% [1]: Cai, Ting, Anna G. Stefanopoulou, and Jason B. Siegel. "Modeling li-ion battery temperature and expansion force during the early stages of thermal runaway triggered by internal shorts." Journal of The Electrochemical Society 166.12 (2019): A2431.
% [2]: Lopez, Carlos F., Judith A. Jeevarajan, and Partha P. Mukherjee. "Experimental analysis of thermal runaway and propagation in lithium-ion battery modules." Journal of the electrochemical society 162.9 (2015): A1905.

%% Some heat transfer parameters
params.heater_power = 5*1e3; %Power of the applied heater.
params.h_tf = 35; % Heat transfer coefficiet between cells,  from  https://core.ac.uk/download/pdf/144147357.pdf
params.sigma_SB = 5.67e-8; % Steffan-Boltzman constant.
params.Cp = 1100; %Specific heat cpaacity of the battery. Value from [1].
params.emisivity_cell = 0.86; % Cell emisivity from https://core.ac.uk/download/pdf/144147357.pdf
params.emisivity = params.emisivity_cell*eye(params.n_cells); % Cell emisivity from https://core.ac.uk/download/pdf/144147357.pdf
params.Cp_fix = 897; % Specific heat capacity of fixings.
params.m_fix = 1100; % mass of fixings.
params.z0 = 0.033; % Initial dimensionless SEI layer thickness.
params.x_an0 = 0.75; %Initial fraction of Li in the anode.

params.cell_height = 65.3e-3; % Height of the cylindircal cells.
params.core_diameter = 9e-3; % Diameter of the cylindrical cells' core.
params.cell_diameter = 18.5e-3; % Diameter of the cylindrical cells.
params.cell_radius= params.cell_diameter*0.5; % Cell radius.

params.A_cylinder = params.cell_height*pi*params.cell_diameter; 

params.density_air = 1.225;
params.v_air_box = 1;
params.m_air_box = params.v_air_box/params.density_air;
params.Cp_air = 0.718e3;

params.tabs_location = [0;0;1]; %Identifies where the tabs are placed on the cell. If they are at the surface, then this parameter should be [1;0;0]. If they are in the cell middle them [0;1;0] and if they are at the core, then [0;0;1];

%% Parameters for the heat distributions between the cells in the pack.
% taken from Lopez, Carlos F., Judith A. Jeevarajan, and Partha P. Mukherjee. "Experimental analysis of thermal runaway and propagation in lithium-ion battery modules." Journal of the electrochemical society 162.9 (2015): A1905.
params.spacing_gap = 1e-2; %The gap between two cells.
params.spacing = 2*params.cell_diameter+params.spacing_gap; % Spacing between the cells in the pack.
denom = acosh((4*params.spacing^2-2*params.cell_diameter^2)/(2*params.cell_diameter^2));
params.S = 2*pi*params.cell_height/denom; % Shape factor
params.k_air = 0.026; % Thermal conductivity of air.
% params.tab_width = 7e-2*params.cell_diameter; % Assumed width of the tabs.
params.tab_width = 7e-3; % Assumed width of the tabs.

params.Atab = params.spacing*params.tab_width; % Surface area of the tabs.
% params.k_tab = 239;  % assuming the tabs are made of aluminium.
% params.k_tab = 5e1;  % assuming the tabs are made of steel.
params.k_tab = 91;  % assuming the tabs are made of nickel.

params.con_air_param = params.k_air*params.S; % Heat condutction rate per cell due to spacing.
params.con_tab_param = params.k_tab*params.Atab/params.spacing;  % Heat condutction rate per cell due to tabs.

C = 1+params.spacing/(0.5*params.cell_diameter);
params.F12 = 1*(pi+(C^2-4)^0.5-C-2*acos(2/C))/(2*pi); % View factor
params.rad_param = params.sigma_SB/(2*(1-params.emisivity_cell)/(params.A_cylinder*params.emisivity_cell)+1/(params.A_cylinder*params.F12));   % Heat radiation rate per cell due to spacing.

%% The masses of the cells
% params.m_mid_Siegel = 4.67; params.m_surf_Siegel = 98.04; params.m_core_Siegel = 1.039; % The various masses from [1].
% params.core_ratio = 1e-2; % The mass ratio between the "core" and the whole cell, following [1]. % params.mid_ratio = 1e-1;  % The mass ratio between the "middle" and the whole cell, following [1].
 params.radius_core = (1/10)*params.cell_radius;  params.radius_mid = params.radius_core+(1/10)*params.cell_radius;  params.radius_surf =params.cell_radius; % the radius of the core, middle and surface regions.
params.core_ratio = params.radius_core/params.cell_radius; params.mid_ratio = (params.radius_mid-params.radius_core)/params.cell_radius; % the ratios of the core and middle ratios.
params.r_avg_core_mid = ((params.radius_mid-params.radius_core)/(2*params.cell_radius)); params.r_avg_surf_mid = ((params.radius_surf-params.radius_mid)/(2*params.cell_radius)); % Average distane between the various regions.

params.mass_total = 48e-3; % The mass of the cell. 
params.m_surf =(1-params.mid_ratio-params.core_ratio)*params.mass_total; params.m_mid =  params.mid_ratio*params.mass_total;  params.m_core = params.core_ratio*params.mass_total; % Store the masses of the core, middle and surface regions of the cell.

ma_Siegel = 19.1073e-3; mc_Siegel =36.56e-3; msep_Siegel =1.5/2*2/1e3; mass_Siegel =103.75e-3; % The masses of the anode ma_Siegel, cathode mc_Siegel, separator msep_Siegel and cell mass_Siegel from [1].
params.ma  =(ma_Siegel/mass_Siegel)*params.mass_total; params.mc = (mc_Siegel/mass_Siegel)*params.mass_total; params.msep = (msep_Siegel/mass_Siegel)*params.mass_total; %Store the masses of the anode, cathode and separator. Estimator from the ratios from [1].

%% The thermal resistances between the core, middle and surface regions
params.r_m2s = 1.61; params.r_s2a = 1; params.r_m2c = 3.18;  params.r_s2f = params.r_s2a;% Thermal resistances between the layers, as described in the ref of the header. params.r_m2s is the thermal resistance between the middle and surface regions of the cell, params.r_m2c is the resistance between the middle and core regions of the cell and params.r_s2a between the air and cell surface. 
% params.r_m2s = 1e-2; params.r_s2a = 1e-2; params.r_m2c = 1e-2; % Thermal resistances between the layers, as described in the ref of the header. params.r_m2s is the thermal resistance between the middle and surface regions of the cell, params.r_m2c is the resistance between the middle and core regions of the cell and params.r_s2a between the air and cell surface. 

 params.k_cell_norm= 1.3461; % thermal conductivity of the whole cell.
params.r_m2s = params.r_avg_surf_mid/params.k_cell_norm; % Thermal resistance between mid and surface. Proportional to the distance between the two regions, which is represented by the mass ratios.
params.r_m2c = params.r_avg_core_mid/params.k_cell_norm; % Thermal resistance between mid and surface. Proportional to the distance between the two regions, which is represented by the mass ratios.
params.r_s2a = 1/params.con_air_param;  % Thermal resistance between air and surface. Obtained from the calculations of [2].
params.r_s2a = 2.2975*4;  % Thermal resistance between air and surface. Obtained from estimated.

%% Various temperatures 
params.isc_temp = 57+273; %The temperature when the internal short trigger activates. From [1].
params.Tamb =  273+25.15; % The ambient temperature before ignition.
params.electrolyte_degrade = 180+273; %The temperature when the electrolyte begins to degrade. From [1].
params.SEI_degrade = 130+273; %The temperature when the SEI layer begins to degrade. From [1].
params.cathode_degrade = 240+273; %The temperature when the cathode begins to degrade. From [1].
params.Tref = 1543; % A reference temperature.
params.Tsep_fail = 150+273; % The temperature when the separator burns, creating a short circuit. 
% params.Tsep_fail = 300+273; % The temperature when the separator burns, creating a short circuit. 
params.Tref_R = 297; 
params.Tpop = 160+273; % The temperature where the cell erupts and so the tabs pop off. 

%% Parameter for decomposition of the electrodes once they have been ignited.
params.ha= 1714; % Enthalpy of anode decomposition.
params.hc = 790; % Enthalpy of cathode decomposition.
params.hs = 257; % Enthalpy of SEI layer decomposition.

params.Aa=2.5*10^13;  % Frequency factor of anode layer decomposition.
params.Ac=2.55*10^14;  % Frequency factor of cathode decomposition.
params.As=2.25*10^15; % Frequency factor of SEI layer decomposition.

params.Ea=1.3508*10^5; % Activation energy of anode decomposition.
params.Ec=1.5888*10^5; % Activation energy of cathode decomposition.
params.Es=1.3508*10^5; % Activation energy of SEI layer decomposition.

params.Asurf=0.0237; % Surface area of the fixings.
params.h = 42.13; % Enthalpy of the fixings.
params.R_constant = 8.314; % Univsersal gas constant.

%%
params.theta_leak = 0;
params.theta_vap = 1e0;
params.B_rate = 1e0;
params.m_vap_lim = 0.01;
params.T_ign = 450;
params.mass_burn_lim = 450;
params.flame_rate = 1e-2;

end


















